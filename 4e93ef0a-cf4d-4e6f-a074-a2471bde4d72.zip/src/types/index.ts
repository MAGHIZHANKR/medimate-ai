export type Role = 'patient' | 'caregiver';

export type Frequency = 'once' | 'daily' | 'twice' | 'three' | 'custom';

export type FoodInstruction = 'before' | 'after' | 'with' | 'none';

export type LogStatus = 'taken' | 'snoozed' | 'missed';

export type OccurrenceStatus = 'taken' | 'snoozed' | 'missed' | 'upcoming' | 'due';

export interface AppUser {
  uid: string;
  name: string;
  email: string;
  role: Role;
  caregiverCode: string;
  createdAt: number;
}

export interface Medicine {
  id: string;
  userId: string;
  name: string;
  dosage: string;
  times: string[];
  frequency: Frequency;
  foodInstruction: FoodInstruction;
  startDate: string;
  endDate: string | null;
  notes: string;
  active: boolean;
  createdAt: number;
  demo?: boolean;
}

export interface MedicineLog {
  id: string;
  medicineId: string;
  userId: string;
  dateKey: string;
  scheduledTime: string;
  status: LogStatus;
  actionTime: number;
  snoozeUntil?: number;
  snoozeCount?: number;
  createdAt: number;
}

export interface CaregiverLink {
  id: string;
  patientId: string;
  caregiverId: string;
  caregiverName: string;
  patientName: string;
  status: 'pending' | 'approved' | 'declined';
  createdAt: number;
}

export interface UserSettings {
  voiceEnabled: boolean;
  gracePeriodMinutes: number;
  notificationsAsked: boolean;
}

export interface Occurrence {
  key: string;
  medicine: Medicine;
  dateKey: string;
  scheduledTime: string;
  scheduledAt: number;
  effectiveAt: number;
  status: OccurrenceStatus;
  log: MedicineLog | null;
}