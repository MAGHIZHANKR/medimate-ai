# MEDIMATE — Never miss a medicine moment.

A medicine reminder and caregiver tracking app for elderly users. MediMate reminds, speaks, and
records what the user reports. It does **not** diagnose, recommend, verify intake, or replace a
doctor.

> **MEDIMATE IS A REMINDER AND TRACKING TOOL. IT DOES NOT PROVIDE MEDICAL ADVICE OR VERIFY THAT
> MEDICINE WAS ACTUALLY TAKEN.**

## What works end to end

- Email/password registration with a **Patient** or **Caregiver** role, login, logout, password
  reset, persisted session.
- Add / edit / pause / delete medicines: dosage, one or more dose times, frequency, food
  instruction, start & end date, notes — all validated.
- A real reminder engine: at the scheduled time you get a **browser notification**, a **spoken
  reminder** (Speech Synthesis), and a large on-screen reminder with **Taken / Snooze 10 min /
  Mark missed**.
- Snooze re-fires the reminder 10 minutes later and is capped at 3 snoozes per dose, so it can
  never loop forever.
- A dose left unanswered past the grace period (10/20/30/60 min, default 30) is recorded as
  **Missed** — never silently dropped.
- Medicine history (14 days) with All / Taken / Missed / Snoozed filters, plus a weekly
  **Reminder Response Rate** (percentage of reminders marked Taken — not a medical outcome).
- Caregiver linking by 6-character code (`MED-4821`) with **patient approval**, and a caregiver
  dashboard that updates live — no refresh — as the patient answers reminders.
- "✨ Create reminder with AI": converts a plain sentence into structured fields, shows a
  **Review before saving** step, and refuses to guess when it is unsure.

## Run it

```bash
npm install
npm run dev
```

## Data layer

Collections follow the Firestore model exactly:

```
users/{uid}              { name, email, role, caregiverCode, createdAt }
medicines/{medicineId}   { userId, name, dosage, times[], frequency, foodInstruction,
                           startDate, endDate, notes, active, createdAt }
medicineLogs/{logId}     { medicineId, userId, dateKey, scheduledTime, status,
                           actionTime, snoozeUntil, snoozeCount, createdAt }
caregiverLinks/{linkId}  { patientId, caregiverId, patientName, caregiverName, status, createdAt }
```

`services/db.ts` implements those collections against browser storage with **live subscriptions**
and cross-tab broadcast, which is what makes the patient → caregiver real-time demo work in two
tabs or two windows. Every read in the app is a subscription, exactly as it would be with
`onSnapshot`.

### Moving to Firebase

1. Create a Firebase project → **Authentication → Sign-in method → Email/Password → Enable**.
2. **Firestore Database → Create database**.
3. Copy the web app config into `.env` using the keys in `.env.example`.
4. Deploy the rules in `firestore.rules`: `firebase deploy --only firestore:rules`.
5. Add `firebase` to `package.json`, then create `firebase/config.ts`:

```ts
import { initializeApp } from 'firebase/app'
import { getAuth } from 'firebase/auth'
import { getFirestore } from 'firebase/firestore'

export const app = initializeApp({
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
})
export const auth = getAuth(app)
export const firestore = getFirestore(app)
```

6. Replace the bodies of the functions in `services/db.ts` one by one — each maps 1:1:

| `services/db.ts`                | Firebase call |
| ------------------------------- | ------------- |
| `signUp` / `signIn` / `signOut` | `createUserWithEmailAndPassword` / `signInWithEmailAndPassword` / `signOut` + `setDoc(doc(firestore,'users',uid))` |
| `resetPassword`                 | `sendPasswordResetEmail` |
| `listMedicines`                 | `onSnapshot(query(collection(firestore,'medicines'), where('userId','==',uid)))` |
| `addMedicine` / `updateMedicine` / `deleteMedicine` | `addDoc` / `updateDoc` / `deleteDoc` |
| `listLogs` / `writeLog`         | `onSnapshot(...)` / `setDoc` with id `${medicineId}_${dateKey}_${scheduledTime}` |
| `listLinks` / `requestLink` / `setLinkStatus` | `onSnapshot(...)` / `setDoc` with id `${patientId}_${caregiverId}` / `updateDoc` |
| `subscribe`                     | the `onSnapshot` unsubscribe handles |

The link document id **must** be `{patientId}_{caregiverId}` — `firestore.rules` uses it to check
approval without letting anyone query other users.

## Demo flow (2 minutes)

1. Register as **Patient** (e.g. Lakshmi). Approve the notification prompt.
2. **Settings → Load demo medicines** (one dose lands ~3 minutes out), or add Metformin, 1 tablet,
   a near-future time, after food.
3. The dashboard updates immediately: next medicine card, today's plan, counters.
4. At the scheduled time the notification fires, the reminder appears, and the voice says:
   *"It's medicine time. Please take Metformin, one tablet, after food."*
5. Press **Taken** → a log is written and the counters move.
6. **Caregiver → copy the code** (e.g. `MED-4821`).
7. In a second browser window, register as **Caregiver**, go to **Patients**, enter the code,
   **Connect**.
8. Back in the patient window: **Caregiver → Approve**.
9. The caregiver dashboard shows the patient's schedule and status **without a refresh**.
10. Snooze a dose in the patient window and watch the caregiver see **Snoozed until …**.
11. Show **History** and the **weekly Reminder Response Rate**.

## Safety behaviour, on purpose

- "Taken" is stored as a **self-report**. The disclaimer appears on the dashboard, medicines page,
  reminder dialog, AI page, and caregiver views.
- The AI parser never invents a medicine name, dosage, time, or frequency. When unsure it says
  *"I couldn't understand the medicine schedule clearly. Please enter it manually."*
- Nothing generated by AI is saved without an explicit review-and-confirm step.
- Denied notification permission never breaks the app — in-app reminders and voice still run.
- Caregivers see data only after the patient approves, and only schedules and reminder responses.

## Project structure

```
App.tsx                  routing + providers
layouts/                 AuthLayout (sign-in), AppLayout (sidebar / bottom nav)
pages/                   patient + caregiver screens
components/              reusable UI (ui/) and app components
contexts/                AuthContext, ToastContext, ReminderContext (reminder engine)
hooks/                   useNow, usePatientData, useCaregiverPatients
services/                db (Firestore layer), notifications, voice, aiParser
utils/                   time + schedule/status maths
types/                   shared types
firestore.rules          production security rules
```
