import type { Frequency, FoodInstruction, Medicine, MedicineLog, Occurrence } from '../types';

export const MINUTE = 60_000;

export function dateKey(d: Date | number): string {
  const date = typeof d === 'number' ? new Date(d) : d;
  const m = `${date.getMonth() + 1}`.padStart(2, '0');
  const day = `${date.getDate()}`.padStart(2, '0');
  return `${date.getFullYear()}-${m}-${day}`;
}

export function addDays(key: string, days: number): string {
  const [y, m, d] = key.split('-').map(Number);
  const date = new Date(y, m - 1, d + days);
  return dateKey(date);
}

export function keyToDate(key: string, time = '00:00'): Date {
  const [y, m, d] = key.split('-').map(Number);
  const [hh, mm] = time.split(':').map(Number);
  return new Date(y, m - 1, d, hh || 0, mm || 0, 0, 0);
}

export function formatTime(time: string): string {
  const [hh, mm] = time.split(':').map(Number);
  const period = hh >= 12 ? 'PM' : 'AM';
  const hour = hh % 12 === 0 ? 12 : hh % 12;
  return `${hour}:${`${mm}`.padStart(2, '0')} ${period}`;
}

export function formatClock(ts: number): string {
  const d = new Date(ts);
  return formatTime(`${`${d.getHours()}`.padStart(2, '0')}:${`${d.getMinutes()}`.padStart(2, '0')}`);
}

export function formatDateLabel(key: string): string {
  const d = keyToDate(key);
  return d.toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' });
}

export function relativeDayLabel(key: string): string {
  const today = dateKey(new Date());
  if (key === today) return 'Today';
  if (key === addDays(today, -1)) return 'Yesterday';
  return formatDateLabel(key);
}

export const FREQUENCY_LABEL: Record<Frequency, string> = {
  once: 'Once only',
  daily: 'Once daily',
  twice: 'Twice daily',
  three: 'Three times daily',
  custom: 'Custom times'
};

export const FOOD_LABEL: Record<FoodInstruction, string> = {
  before: 'Before food',
  after: 'After food',
  with: 'With food',
  none: 'No food instruction'
};

export function timesCountFor(frequency: Frequency): number {
  if (frequency === 'twice') return 2;
  if (frequency === 'three') return 3;
  return 1;
}

export function defaultTimesFor(frequency: Frequency): string[] {
  if (frequency === 'twice') return ['08:00', '20:00'];
  if (frequency === 'three') return ['08:00', '14:00', '20:00'];
  return ['08:00'];
}

function isScheduledOn(medicine: Medicine, key: string): boolean {
  if (!medicine.active) return false;
  if (key < medicine.startDate) return false;
  if (medicine.endDate && key > medicine.endDate) return false;
  if (medicine.frequency === 'once' && key !== medicine.startDate) return false;
  return true;
}

export function occurrenceKey(medicineId: string, key: string, time: string): string {
  return `${medicineId}__${key}__${time}`;
}

/** Builds every scheduled dose for a day and resolves its current status. */
export function occurrencesForDay(
medicines: Medicine[],
logs: MedicineLog[],
key: string,
graceMinutes: number,
now: number)
: Occurrence[] {
  const result: Occurrence[] = [];
  for (const medicine of medicines) {
    if (!isScheduledOn(medicine, key)) continue;
    for (const time of medicine.times) {
      const scheduledAt = keyToDate(key, time).getTime();
      const log =
      logs.find(
        (l) => l.medicineId === medicine.id && l.dateKey === key && l.scheduledTime === time
      ) ?? null;
      let effectiveAt = scheduledAt;
      let status: Occurrence['status'] = 'upcoming';

      if (log?.status === 'taken') {
        status = 'taken';
      } else if (log?.status === 'missed') {
        status = 'missed';
      } else if (log?.status === 'snoozed' && log.snoozeUntil) {
        effectiveAt = log.snoozeUntil;
        if (now >= effectiveAt + graceMinutes * MINUTE) status = 'missed';else
        if (now >= effectiveAt) status = 'due';else
        status = 'snoozed';
      } else if (now >= scheduledAt + graceMinutes * MINUTE) {
        status = 'missed';
      } else if (now >= scheduledAt) {
        status = 'due';
      }

      result.push({
        key: occurrenceKey(medicine.id, key, time),
        medicine,
        dateKey: key,
        scheduledTime: time,
        scheduledAt,
        effectiveAt,
        status,
        log
      });
    }
  }
  return result.sort((a, b) => a.scheduledAt - b.scheduledAt);
}

export function occurrencesForRange(
medicines: Medicine[],
logs: MedicineLog[],
days: number,
graceMinutes: number,
now: number)
: Occurrence[] {
  const today = dateKey(new Date(now));
  const out: Occurrence[] = [];
  for (let i = 0; i < days; i += 1) {
    out.push(...occurrencesForDay(medicines, logs, addDays(today, -i), graceMinutes, now));
  }
  return out.sort((a, b) => b.scheduledAt - a.scheduledAt);
}

export function countByStatus(occurrences: Occurrence[]) {
  const counts = { taken: 0, snoozed: 0, missed: 0, upcoming: 0, due: 0 };
  for (const o of occurrences) counts[o.status] += 1;
  return counts;
}

export function responseRate(occurrences: Occurrence[]): number {
  const resolved = occurrences.filter((o) => o.status !== 'upcoming');
  if (!resolved.length) return 0;
  const taken = resolved.filter((o) => o.status === 'taken').length;
  return Math.round(taken / resolved.length * 100);
}