import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Field';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { AppError } from '../services/db';

export function Login() {
  const { signIn } = useAuth();
  const { notify } = useToast();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState<{email?: string;password?: string;}>({});
  const [formError, setFormError] = useState('');
  const [loading, setLoading] = useState(false);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    const nextErrors: typeof errors = {};
    if (!email.trim()) nextErrors.email = 'Enter your email address.';else
    if (!/^\S+@\S+\.\S+$/.test(email.trim())) nextErrors.email = 'That email looks incomplete.';
    if (!password) nextErrors.password = 'Enter your password.';
    setErrors(nextErrors);
    setFormError('');
    if (Object.keys(nextErrors).length) return;

    setLoading(true);
    try {
      const user = await signIn(email, password);
      notify(`Welcome back, ${user.name.split(' ')[0]}`, 'success');
      navigate('/dashboard', { replace: true });
    } catch (error) {
      setFormError(
        error instanceof AppError ?
        error.message :
        'We could not sign you in right now. Please try again.'
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="p-6 sm:p-8">
      <h1 className="text-3xl font-extrabold tracking-tight text-ink">Log in</h1>
      <p className="mt-2 text-base text-ink-muted">
        Welcome back. Your reminders are waiting for you.
      </p>

      <form className="mt-7 flex flex-col gap-5" onSubmit={submit} noValidate>
        <Input
          label="Email"
          type="email"
          autoComplete="email"
          value={email}
          error={errors.email}
          onChange={(event) => setEmail(event.target.value)}
          placeholder="you@example.com" />
        
        <Input
          label="Password"
          type="password"
          autoComplete="current-password"
          value={password}
          error={errors.password}
          onChange={(event) => setPassword(event.target.value)}
          placeholder="••••••••" />
        

        {formError &&
        <p
          role="alert"
          className="rounded-2xl border border-status-missed/30 bg-status-missedSoft px-4 py-3 text-base font-semibold text-status-missed">
          
            {formError}
          </p>
        }

        <Button type="submit" size="lg" loading={loading} fullWidth>
          {loading ? 'Logging in…' : 'Log in'}
        </Button>
      </form>

      <div className="mt-6 flex flex-col gap-3 border-t border-line pt-6">
        <Link
          to="/forgot-password"
          className="text-base font-semibold text-primary-700 underline-offset-4 hover:underline">
          
          Forgot password?
        </Link>
        <p className="text-base text-ink-muted">
          New to MediMate?{' '}
          <Link
            to="/register"
            className="font-bold text-primary-700 underline-offset-4 hover:underline">
            
            Create an account
          </Link>
        </p>
      </div>
    </Card>);

}