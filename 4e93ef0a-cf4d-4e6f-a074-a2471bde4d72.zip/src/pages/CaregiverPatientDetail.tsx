import React from 'react';
import { Link, useParams } from 'react-router-dom';
import { ArrowLeftIcon, ClipboardListIcon, UserRoundIcon } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useNow } from '../hooks/useNow';
import { useCaregiverPatients } from '../hooks/useCaregiverPatients';
import { Card, SectionHeading } from '../components/ui/Card';
import { EmptyState, LoadingState } from '../components/ui/EmptyState';
import { DoseRow } from '../components/DoseRow';
import { WeeklyResponse } from '../components/WeeklyResponse';
import { Disclaimer } from '../components/Brand';
import {
  countByStatus,
  dateKey,
  occurrencesForDay,
  occurrencesForRange,
  relativeDayLabel } from
'../utils/time';

export function CaregiverPatientDetail() {
  const { patientId } = useParams<{patientId: string;}>();
  const { user } = useAuth();
  const now = useNow(10_000);
  const { patients, loading } = useCaregiverPatients(user?.uid);
  const bundle = patients.find((item) => item.patient.uid === patientId);

  if (loading) return <LoadingState label="Loading patient…" />;

  if (!bundle) {
    return (
      <div className="flex flex-col gap-6">
        <Link
          to="/patients"
          className="inline-flex items-center gap-2 text-base font-bold text-primary-700 hover:underline">
          
          <ArrowLeftIcon className="h-5 w-5" aria-hidden="true" />
          Back to patients
        </Link>
        <EmptyState
          icon={<UserRoundIcon className="h-8 w-8" aria-hidden="true" />}
          title="This patient is not available"
          message="Either the connection was removed, or it has not been approved yet. Ask the patient to approve your request." />
        
      </div>);

  }

  const today = dateKey(new Date(now));
  const grace = bundle.settings.gracePeriodMinutes;
  const todaysDoses = occurrencesForDay(bundle.medicines, bundle.logs, today, grace, now);
  const counts = countByStatus(todaysDoses);
  const recent = occurrencesForRange(bundle.medicines, bundle.logs, 7, grace, now).filter(
    (dose) => dose.dateKey !== today
  );

  return (
    <div className="flex flex-col gap-6">
      <Link
        to="/patients"
        className="inline-flex w-fit items-center gap-2 text-base font-bold text-primary-700 hover:underline">
        
        <ArrowLeftIcon className="h-5 w-5" aria-hidden="true" />
        Back to patients
      </Link>

      <Card className="flex flex-col gap-5 sm:flex-row sm:items-center">
        <span className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-primary-50 text-primary-600">
          <UserRoundIcon className="h-8 w-8" aria-hidden="true" />
        </span>
        <div className="flex-1">
          <h1 className="text-3xl font-extrabold tracking-tight text-ink">
            {bundle.patient.name}
          </h1>
          <p className="mt-1 text-base text-ink-muted">
            {todaysDoses.length} scheduled today · {counts.taken} taken ·{' '}
            {counts.upcoming + counts.due + counts.snoozed} upcoming · {counts.missed} missed
          </p>
        </div>
      </Card>

      <section aria-labelledby="today-heading">
        <SectionHeading title="Today's medicines" subtitle="Updates live as they are answered." />
        <h2 id="today-heading" className="sr-only">
          Today's medicines
        </h2>
        {todaysDoses.length === 0 ?
        <EmptyState
          icon={<ClipboardListIcon className="h-8 w-8" aria-hidden="true" />}
          title="Nothing scheduled today"
          message="This patient has no doses scheduled for today." /> :


        <ul className="flex flex-col gap-3">
            {todaysDoses.map((dose) =>
          <DoseRow key={dose.key} occurrence={dose} />
          )}
          </ul>
        }
      </section>

      <WeeklyResponse
        medicines={bundle.medicines}
        logs={bundle.logs}
        graceMinutes={grace}
        now={now} />
      

      <section aria-labelledby="recent-heading">
        <SectionHeading title="Earlier this week" subtitle="Previous six days of reminders." />
        <h2 id="recent-heading" className="sr-only">
          Earlier this week
        </h2>
        {recent.length === 0 ?
        <EmptyState
          icon={<ClipboardListIcon className="h-8 w-8" aria-hidden="true" />}
          title="No earlier activity yet"
          message="Reminder responses from previous days will show up here." /> :


        <ul className="flex flex-col gap-3">
            {recent.map((dose) =>
          <DoseRow
            key={dose.key}
            occurrence={dose}
            dateLabel={relativeDayLabel(dose.dateKey)} />

          )}
          </ul>
        }
      </section>

      <Disclaimer />
    </div>);

}