import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Field';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { AppError } from '../services/db';

export function ForgotPassword() {
  const { resetPassword } = useAuth();
  const { notify } = useToast();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState('');
  const [loading, setLoading] = useState(false);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    const next: Record<string, string> = {};
    if (!/^\S+@\S+\.\S+$/.test(email.trim())) next.email = 'Enter the email on your account.';
    if (password.length < 6) next.password = 'Use at least 6 characters.';
    setErrors(next);
    setFormError('');
    if (Object.keys(next).length) return;

    setLoading(true);
    try {
      await resetPassword(email, password);
      notify('Password updated. You can log in now.', 'success');
      navigate('/login', { replace: true });
    } catch (error) {
      setFormError(
        error instanceof AppError ?
        error.message :
        'We could not reset the password right now. Please try again.'
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="p-6 sm:p-8">
      <h1 className="text-3xl font-extrabold tracking-tight text-ink">Reset your password</h1>
      <p className="mt-2 text-base text-ink-muted">
        Confirm your email and choose a new password.
      </p>

      <form className="mt-7 flex flex-col gap-5" onSubmit={submit} noValidate>
        <Input
          label="Email"
          type="email"
          value={email}
          error={errors.email}
          onChange={(event) => setEmail(event.target.value)}
          autoComplete="email" />
        
        <Input
          label="New password"
          type="password"
          value={password}
          error={errors.password}
          onChange={(event) => setPassword(event.target.value)}
          autoComplete="new-password" />
        

        {formError &&
        <p
          role="alert"
          className="rounded-2xl border border-status-missed/30 bg-status-missedSoft px-4 py-3 text-base font-semibold text-status-missed">
          
            {formError}
          </p>
        }

        <Button type="submit" size="lg" loading={loading} fullWidth>
          {loading ? 'Updating…' : 'Update password'}
        </Button>
      </form>

      <p className="mt-6 border-t border-line pt-6 text-base text-ink-muted">
        <Link to="/login" className="font-bold text-primary-700 underline-offset-4 hover:underline">
          Back to log in
        </Link>
      </p>
    </Card>);

}