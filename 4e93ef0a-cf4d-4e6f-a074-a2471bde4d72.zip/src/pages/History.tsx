import React, { useMemo, useState } from 'react';
import { ClipboardListIcon } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useReminders } from '../contexts/ReminderContext';
import { SectionHeading } from '../components/ui/Card';
import { EmptyState, LoadingState } from '../components/ui/EmptyState';
import { DoseRow } from '../components/DoseRow';
import { WeeklyResponse } from '../components/WeeklyResponse';
import { occurrencesForRange, relativeDayLabel } from '../utils/time';
import type { OccurrenceStatus } from '../types';

const FILTERS: {value: 'all' | OccurrenceStatus;label: string;}[] = [
{ value: 'all', label: 'All' },
{ value: 'taken', label: 'Taken' },
{ value: 'missed', label: 'Missed' },
{ value: 'snoozed', label: 'Snoozed' }];


export function History() {
  const { settings } = useAuth();
  const { medicines, logs, loading, now } = useReminders();
  const [filter, setFilter] = useState<'all' | OccurrenceStatus>('all');

  const doses = useMemo(
    () => occurrencesForRange(medicines, logs, 14, settings.gracePeriodMinutes, now),
    [medicines, logs, settings.gracePeriodMinutes, now]
  );

  const visible = useMemo(
    () =>
    doses.filter((dose) => {
      if (filter === 'all') return true;
      if (filter === 'snoozed') return (dose.log?.snoozeCount ?? 0) > 0;
      return dose.status === filter;
    }),
    [doses, filter]
  );

  return (
    <div className="flex flex-col gap-6">
      <SectionHeading
        title="Medicine history"
        subtitle="The last 14 days of scheduled reminders and how they were answered." />
      

      <WeeklyResponse
        medicines={medicines}
        logs={logs}
        graceMinutes={settings.gracePeriodMinutes}
        now={now} />
      

      <div className="flex flex-wrap gap-2" role="group" aria-label="Filter history">
        {FILTERS.map((option) => {
          const active = filter === option.value;
          return (
            <button
              key={option.value}
              type="button"
              onClick={() => setFilter(option.value)}
              aria-pressed={active}
              className={`min-h-[48px] rounded-2xl border px-5 text-base font-bold transition-colors duration-150 ease-out ${
              active ?
              'border-primary-600 bg-primary-600 text-white' :
              'border-line bg-surface text-ink-muted hover:border-primary-300 hover:text-primary-700'}`
              }>
              
              {option.label}
            </button>);

        })}
      </div>

      {loading ?
      <LoadingState label="Loading history…" /> :
      visible.length === 0 ?
      <EmptyState
        icon={<ClipboardListIcon className="h-8 w-8" aria-hidden="true" />}
        title="Your medicine activity will appear here."
        message={
        filter === 'all' ?
        'Once reminders start being answered, every dose shows up in this list.' :
        'Nothing recorded with this status in the last 14 days.'
        } /> :


      <ul className="flex flex-col gap-3">
          {visible.map((dose) =>
        <DoseRow
          key={dose.key}
          occurrence={dose}
          dateLabel={relativeDayLabel(dose.dateKey)} />

        )}
        </ul>
      }
    </div>);

}