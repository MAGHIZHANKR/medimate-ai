import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { CheckIcon, HeartHandshakeIcon, UserRoundIcon } from 'lucide-react';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Field';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { AppError } from '../services/db';
import type { Role } from '../types';

const ROLES: {value: Role;title: string;body: string;icon: React.ReactNode;}[] = [
{
  value: 'patient',
  title: "I'm a Patient",
  body: 'Get reminders for my own medicines.',
  icon: <UserRoundIcon className="h-7 w-7" aria-hidden="true" />
},
{
  value: 'caregiver',
  title: "I'm a Caregiver",
  body: 'Follow the medicines of someone I care for.',
  icon: <HeartHandshakeIcon className="h-7 w-7" aria-hidden="true" />
}];


export function Register() {
  const { signUp } = useAuth();
  const { notify } = useToast();
  const navigate = useNavigate();
  const [form, setForm] = useState({
    name: '',
    email: '',
    password: '',
    confirm: ''
  });
  const [role, setRole] = useState<Role>('patient');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState('');
  const [loading, setLoading] = useState(false);

  const update = (key: keyof typeof form) => (event: React.ChangeEvent<HTMLInputElement>) =>
  setForm((current) => ({ ...current, [key]: event.target.value }));

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    const next: Record<string, string> = {};
    if (!form.name.trim()) next.name = 'Enter your full name.';
    if (!/^\S+@\S+\.\S+$/.test(form.email.trim())) next.email = 'Enter a valid email address.';
    if (form.password.length < 6) next.password = 'Use at least 6 characters.';
    if (form.password !== form.confirm) next.confirm = 'Passwords do not match.';
    setErrors(next);
    setFormError('');
    if (Object.keys(next).length) return;

    setLoading(true);
    try {
      await signUp({
        name: form.name,
        email: form.email,
        password: form.password,
        role
      });
      notify('Account created. Welcome to MediMate!', 'success');
      navigate('/dashboard', { replace: true });
    } catch (error) {
      setFormError(
        error instanceof AppError ?
        error.message :
        'We could not create your account right now. Please try again.'
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="p-6 sm:p-8">
      <h1 className="text-3xl font-extrabold tracking-tight text-ink">Create your account</h1>
      <p className="mt-2 text-base text-ink-muted">Two minutes now, no missed doses later.</p>

      <form className="mt-7 flex flex-col gap-5" onSubmit={submit} noValidate>
        <fieldset>
          <legend className="mb-3 text-base font-semibold text-ink">I am using MediMate as</legend>
          <div className="grid gap-3 sm:grid-cols-2">
            {ROLES.map((option) => {
              const selected = role === option.value;
              return (
                <button
                  key={option.value}
                  type="button"
                  onClick={() => setRole(option.value)}
                  aria-pressed={selected}
                  className={`flex min-h-[120px] flex-col items-start gap-2 rounded-2xl border-2 p-4 text-left transition-[border-color,background-color] duration-150 ease-out ${
                  selected ?
                  'border-primary-600 bg-primary-50' :
                  'border-line bg-white hover:border-primary-300'}`
                  }>
                  
                  <span className="flex w-full items-start justify-between">
                    <span
                      className={`flex h-12 w-12 items-center justify-center rounded-xl ${
                      selected ? 'bg-primary-600 text-white' : 'bg-canvas text-primary-600'}`
                      }>
                      
                      {option.icon}
                    </span>
                    {selected &&
                    <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary-600 text-white">
                        <CheckIcon className="h-4 w-4" strokeWidth={3} aria-hidden="true" />
                      </span>
                    }
                  </span>
                  <span className="text-lg font-bold text-ink">{option.title}</span>
                  <span className="text-sm text-ink-muted">{option.body}</span>
                </button>);

            })}
          </div>
        </fieldset>

        <Input
          label="Full name"
          value={form.name}
          error={errors.name}
          onChange={update('name')}
          autoComplete="name"
          placeholder="Lakshmi Iyer" />
        
        <Input
          label="Email"
          type="email"
          value={form.email}
          error={errors.email}
          onChange={update('email')}
          autoComplete="email"
          placeholder="you@example.com" />
        
        <Input
          label="Password"
          type="password"
          value={form.password}
          error={errors.password}
          onChange={update('password')}
          autoComplete="new-password"
          hint="At least 6 characters." />
        
        <Input
          label="Confirm password"
          type="password"
          value={form.confirm}
          error={errors.confirm}
          onChange={update('confirm')}
          autoComplete="new-password" />
        

        {formError &&
        <p
          role="alert"
          className="rounded-2xl border border-status-missed/30 bg-status-missedSoft px-4 py-3 text-base font-semibold text-status-missed">
          
            {formError}
          </p>
        }

        <Button type="submit" size="lg" loading={loading} fullWidth>
          {loading ? 'Creating account…' : 'Create account'}
        </Button>
      </form>

      <p className="mt-6 border-t border-line pt-6 text-base text-ink-muted">
        Already have an account?{' '}
        <Link to="/login" className="font-bold text-primary-700 underline-offset-4 hover:underline">
          Log in
        </Link>
      </p>
    </Card>);

}