import React, { useState } from 'react';
import { ClockIcon, LinkIcon, ShieldCheckIcon, UsersRoundIcon, XIcon } from 'lucide-react';
import * as db from '../services/db';
import { AppError } from '../services/db';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { useNow } from '../hooks/useNow';
import { useCaregiverPatients } from '../hooks/useCaregiverPatients';
import { Card, SectionHeading } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Field';
import { EmptyState, LoadingState } from '../components/ui/EmptyState';
import { PatientSummaryCard } from '../components/PatientSummaryCard';

export function CaregiverPatients() {
  const { user } = useAuth();
  const { notify } = useToast();
  const now = useNow(15_000);
  const { patients, pending, links, loading } = useCaregiverPatients(user?.uid);
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [connecting, setConnecting] = useState(false);

  const declined = links.filter((link) => link.status === 'declined');

  const connect = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!user) return;
    if (!/^MED-\d{4}$/i.test(code.trim())) {
      setError('Codes look like MED-4821.');
      return;
    }
    setError('');
    setConnecting(true);
    try {
      const link = db.requestLink(user, code);
      notify(`Request sent to ${link.patientName}. They need to approve it.`, 'success');
      setCode('');
    } catch (err) {
      setError(
        err instanceof AppError ? err.message : 'We could not send that request. Try again.'
      );
    } finally {
      setConnecting(false);
    }
  };

  return (
    <div className="flex flex-col gap-6">
      <SectionHeading
        title="Patients"
        subtitle="Connect with a patient code, then wait for their approval." />
      

      <Card as="section" aria-labelledby="connect-heading">
        <h2 id="connect-heading" className="text-xl font-bold text-ink">
          Connect a patient
        </h2>
        <form className="mt-4 flex flex-col gap-4 sm:flex-row sm:items-end" onSubmit={connect}>
          <Input
            label="Patient code"
            value={code}
            error={error}
            onChange={(event) => setCode(event.target.value.toUpperCase())}
            placeholder="MED-4821"
            className="flex-1"
            hint="Ask the patient to read the code from their Caregiver page." />
          
          <Button type="submit" size="lg" loading={connecting} className="sm:mb-1">
            <LinkIcon className="h-5 w-5" aria-hidden="true" />
            {connecting ? 'Connecting…' : 'Connect'}
          </Button>
        </form>
      </Card>

      {pending.length > 0 &&
      <section aria-labelledby="pending-heading">
          <h2 id="pending-heading" className="mb-3 text-xl font-bold text-ink">
            Waiting for approval
          </h2>
          <ul className="flex flex-col gap-3">
            {pending.map((link) =>
          <Card as="li" key={link.id} className="flex items-center gap-4">
                <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-status-snoozedSoft text-status-snoozed">
                  <ClockIcon className="h-6 w-6" aria-hidden="true" />
                </span>
                <div className="flex-1">
                  <p className="text-lg font-bold text-ink">{link.patientName}</p>
                  <p className="text-base text-ink-muted">
                    Request sent. Nothing is shared until they approve.
                  </p>
                </div>
                <Button variant="danger" onClick={() => db.removeLink(link.id)}>
                  <XIcon className="h-5 w-5" aria-hidden="true" />
                  Cancel
                </Button>
              </Card>
          )}
          </ul>
        </section>
      }

      {declined.length > 0 &&
      <p className="rounded-2xl border border-status-missed/25 bg-status-missedSoft px-4 py-3 text-base font-semibold text-status-missed">
          {declined.length === 1 ?
        `${declined[0].patientName} declined your request.` :
        `${declined.length} requests were declined.`}
        </p>
      }

      <section aria-labelledby="connected-heading">
        <h2 id="connected-heading" className="mb-3 text-xl font-bold text-ink">
          Connected patients
        </h2>
        {loading ?
        <LoadingState label="Loading patients…" /> :
        patients.length === 0 ?
        <EmptyState
          icon={<UsersRoundIcon className="h-8 w-8" aria-hidden="true" />}
          title="No patient connected yet."
          message="Once a patient approves your request, their daily schedule and reminder responses appear here." /> :


        <ul className="grid gap-4 xl:grid-cols-2">
            {patients.map((bundle) =>
          <PatientSummaryCard key={bundle.patient.uid} bundle={bundle} now={now} />
          )}
          </ul>
        }
      </section>

      <p className="flex items-start gap-2 rounded-2xl border border-line bg-surface px-4 py-3 text-sm text-ink-muted">
        <ShieldCheckIcon className="mt-0.5 h-5 w-5 shrink-0 text-primary-600" aria-hidden="true" />
        You can only see patients who approved you, and only their schedule and reminder responses.
        A “Taken” entry is the patient's own report — MediMate cannot verify medication intake.
      </p>
    </div>);

}