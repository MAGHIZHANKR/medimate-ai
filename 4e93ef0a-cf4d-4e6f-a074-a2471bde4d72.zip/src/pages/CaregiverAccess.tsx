import React, { useState } from 'react';
import { CheckIcon, CopyIcon, ShieldCheckIcon, UserRoundIcon, XIcon } from 'lucide-react';
import * as db from '../services/db';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { useReminders } from '../contexts/ReminderContext';
import { Card, SectionHeading } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { EmptyState } from '../components/ui/EmptyState';
import { ConfirmDialog } from '../components/ui/Modal';
import type { CaregiverLink } from '../types';

export function CaregiverAccess() {
  const { user } = useAuth();
  const { notify } = useToast();
  const { links } = useReminders();
  const [pendingRemove, setPendingRemove] = useState<CaregiverLink | null>(null);
  const [copied, setCopied] = useState(false);

  const requests = links.filter((link) => link.status === 'pending');
  const approved = links.filter((link) => link.status === 'approved');

  const copyCode = async () => {
    if (!user) return;
    try {
      await navigator.clipboard.writeText(user.caregiverCode);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      notify('Copying is blocked in this browser — read the code out instead.', 'info');
    }
  };

  return (
    <div className="flex flex-col gap-6">
      <SectionHeading
        title="Caregiver"
        subtitle="Share your code with one person you trust. You approve every request." />
      

      <Card className="bg-primary-700 text-white">
        <p className="text-sm font-bold uppercase tracking-[0.14em] text-primary-100">
          Your caregiver code
        </p>
        <p className="mt-3 text-5xl font-extrabold tracking-[0.08em]">{user?.caregiverCode}</p>
        <p className="mt-3 max-w-lg text-base text-primary-100">
          Your caregiver enters this code in their app. Nothing is shared until you approve the
          request below.
        </p>
        <Button
          variant="secondary"
          className="mt-5 border-white bg-white text-primary-700"
          onClick={copyCode}>
          
          {copied ?
          <CheckIcon className="h-5 w-5" aria-hidden="true" /> :

          <CopyIcon className="h-5 w-5" aria-hidden="true" />
          }
          {copied ? 'Code copied' : 'Copy code'}
        </Button>
      </Card>

      {requests.length > 0 &&
      <section aria-labelledby="requests-heading">
          <h2 id="requests-heading" className="mb-3 text-xl font-bold text-ink">
            Connection requests
          </h2>
          <ul className="flex flex-col gap-3">
            {requests.map((link) =>
          <Card as="li" key={link.id} className="flex flex-col gap-4 sm:flex-row sm:items-center">
                <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-status-upcomingSoft text-status-upcoming">
                  <UserRoundIcon className="h-6 w-6" aria-hidden="true" />
                </span>
                <p className="flex-1 text-lg font-semibold text-ink">
                  {link.caregiverName} wants to connect as your caregiver.
                </p>
                <div className="flex gap-2">
                  <Button
                onClick={() => {
                  db.setLinkStatus(link.id, 'approved');
                  notify(`${link.caregiverName} can now follow your reminders.`, 'success');
                }}>
                
                    <CheckIcon className="h-5 w-5" aria-hidden="true" />
                    Approve
                  </Button>
                  <Button
                variant="danger"
                onClick={() => {
                  db.setLinkStatus(link.id, 'declined');
                  notify('Request declined.', 'info');
                }}>
                
                    <XIcon className="h-5 w-5" aria-hidden="true" />
                    Decline
                  </Button>
                </div>
              </Card>
          )}
          </ul>
        </section>
      }

      <section aria-labelledby="connected-heading">
        <h2 id="connected-heading" className="mb-3 text-xl font-bold text-ink">
          Connected caregivers
        </h2>
        {approved.length === 0 ?
        <EmptyState
          icon={<ShieldCheckIcon className="h-8 w-8" aria-hidden="true" />}
          title="No caregiver connected yet."
          message="Share the code above with a family member. They will only see your medicine schedule and how each reminder was answered." /> :


        <ul className="flex flex-col gap-3">
            {approved.map((link) =>
          <Card as="li" key={link.id} className="flex flex-col gap-4 sm:flex-row sm:items-center">
                <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-status-takenSoft text-status-taken">
                  <ShieldCheckIcon className="h-6 w-6" aria-hidden="true" />
                </span>
                <div className="flex-1">
                  <p className="text-lg font-bold text-ink">{link.caregiverName}</p>
                  <p className="text-base text-ink-muted">
                    Can see today's schedule and reminder responses.
                  </p>
                </div>
                <Button variant="danger" onClick={() => setPendingRemove(link)}>
                  Remove access
                </Button>
              </Card>
          )}
          </ul>
        }
      </section>

      <ConfirmDialog
        open={Boolean(pendingRemove)}
        title={`Remove ${pendingRemove?.caregiverName ?? 'caregiver'}?`}
        message="They will immediately lose access to your medicine schedule and history."
        confirmLabel="Remove access"
        tone="danger"
        onCancel={() => setPendingRemove(null)}
        onConfirm={() => {
          if (!pendingRemove) return;
          db.removeLink(pendingRemove.id);
          notify('Caregiver access removed.', 'info');
          setPendingRemove(null);
        }} />
      
    </div>);

}