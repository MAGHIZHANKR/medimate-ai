import React, { useState } from 'react';
import {
  PencilIcon,
  PillIcon,
  PlusIcon,
  SparklesIcon,
  Trash2Icon,
  UtensilsIcon } from
'lucide-react';
import * as db from '../services/db';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { useReminders } from '../contexts/ReminderContext';
import { Card, SectionHeading } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { EmptyState, LoadingState } from '../components/ui/EmptyState';
import { ConfirmDialog } from '../components/ui/Modal';
import { Disclaimer } from '../components/Brand';
import { MedicineForm } from '../components/MedicineForm';
import { AiReminderModal } from '../components/AiReminderModal';
import { FOOD_LABEL, FREQUENCY_LABEL, formatDateLabel, formatTime } from '../utils/time';
import type { Medicine } from '../types';
import type { ParsedReminder } from '../services/aiParser';

export function Medicines() {
  const { user } = useAuth();
  const { notify } = useToast();
  const { medicines, loading } = useReminders();
  const [formOpen, setFormOpen] = useState(false);
  const [aiOpen, setAiOpen] = useState(false);
  const [editing, setEditing] = useState<Medicine | null>(null);
  const [prefill, setPrefill] = useState<ParsedReminder | null>(null);
  const [pendingDelete, setPendingDelete] = useState<Medicine | null>(null);

  const openAdd = () => {
    setEditing(null);
    setPrefill(null);
    setFormOpen(true);
  };

  return (
    <div className="flex flex-col gap-6">
      <SectionHeading
        title="My medicines"
        subtitle="Everything MediMate will remind you about."
        action={
        <div className="flex flex-wrap gap-2">
            <Button variant="secondary" onClick={() => setAiOpen(true)}>
              <SparklesIcon className="h-5 w-5" aria-hidden="true" />
              Create reminder with AI
            </Button>
            <Button onClick={openAdd}>
              <PlusIcon className="h-5 w-5" aria-hidden="true" />
              Add medicine
            </Button>
          </div>
        } />
      

      {loading ?
      <LoadingState label="Loading medicines…" /> :
      medicines.length === 0 ?
      <EmptyState
        icon={<PillIcon className="h-8 w-8 -rotate-45" aria-hidden="true" />}
        title="You're all set! Add your first medicine reminder."
        message="Add a medicine with its dosage and time, and MediMate takes care of the reminding."
        action={
        <Button size="lg" onClick={openAdd}>
              <PlusIcon className="h-5 w-5" aria-hidden="true" />
              Add medicine
            </Button>
        } /> :


      <ul className="grid gap-3 lg:grid-cols-2">
          {medicines.map((medicine) =>
        <Card as="li" key={medicine.id} className="flex flex-col gap-4">
              <div className="flex items-start gap-4">
                <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary-50 text-primary-600">
                  <PillIcon className="h-6 w-6 -rotate-45" aria-hidden="true" />
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-baseline gap-x-3">
                    <h3 className="text-xl font-bold text-ink">{medicine.name}</h3>
                    <p className="text-base font-semibold text-ink-muted">{medicine.dosage}</p>
                  </div>
                  <p className="mt-1 text-base text-ink-muted">
                    {FREQUENCY_LABEL[medicine.frequency]} ·{' '}
                    {medicine.times.map(formatTime).join(', ')}
                  </p>
                  {medicine.foodInstruction !== 'none' &&
              <p className="mt-1 flex items-center gap-1.5 text-base text-ink-muted">
                      <UtensilsIcon className="h-4 w-4" aria-hidden="true" />
                      {FOOD_LABEL[medicine.foodInstruction]}
                    </p>
              }
                  <p className="mt-1 text-sm text-ink-subtle">
                    From {formatDateLabel(medicine.startDate)}
                    {medicine.endDate ? ` to ${formatDateLabel(medicine.endDate)}` : ' · ongoing'}
                    {medicine.demo ? ' · demo data' : ''}
                  </p>
                  {medicine.notes &&
              <p className="mt-3 rounded-xl bg-canvas px-3 py-2 text-base text-ink-muted">
                      {medicine.notes}
                    </p>
              }
                </div>
              </div>

              <div className="mt-auto flex flex-wrap gap-2 border-t border-line pt-4">
                <Button
              variant="secondary"
              onClick={() => {
                setEditing(medicine);
                setPrefill(null);
                setFormOpen(true);
              }}>
              
                  <PencilIcon className="h-5 w-5" aria-hidden="true" />
                  Edit
                </Button>
                <Button
              variant="secondary"
              onClick={() => db.updateMedicine(medicine.id, { active: !medicine.active })}>
              
                  {medicine.active ? 'Pause reminders' : 'Resume reminders'}
                </Button>
                <Button variant="danger" onClick={() => setPendingDelete(medicine)}>
                  <Trash2Icon className="h-5 w-5" aria-hidden="true" />
                  Delete
                </Button>
              </div>
            </Card>
        )}
        </ul>
      }

      <Disclaimer />

      <MedicineForm
        open={formOpen}
        medicine={editing}
        prefill={prefill}
        reviewNotice={prefill ? 'Check every field before saving.' : undefined}
        onClose={() => {
          setFormOpen(false);
          setEditing(null);
          setPrefill(null);
        }} />
      

      <AiReminderModal
        open={aiOpen}
        onClose={() => setAiOpen(false)}
        onAccept={(parsed) => {
          setAiOpen(false);
          setEditing(null);
          setPrefill(parsed);
          setFormOpen(true);
        }} />
      

      <ConfirmDialog
        open={Boolean(pendingDelete)}
        title={`Delete ${pendingDelete?.name ?? 'medicine'}?`}
        message="This removes the medicine and its reminder history. This cannot be undone."
        confirmLabel="Delete medicine"
        tone="danger"
        onCancel={() => setPendingDelete(null)}
        onConfirm={() => {
          if (!pendingDelete || !user) return;
          db.deleteMedicine(pendingDelete.id);
          notify(`${pendingDelete.name} deleted`, 'info');
          setPendingDelete(null);
        }} />
      
    </div>);

}