import React, { useMemo, useState } from 'react';
import { ActivityIcon } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useNow } from '../hooks/useNow';
import { useCaregiverPatients } from '../hooks/useCaregiverPatients';
import { SectionHeading } from '../components/ui/Card';
import { EmptyState, LoadingState } from '../components/ui/EmptyState';
import { DoseRow } from '../components/DoseRow';
import { Disclaimer } from '../components/Brand';
import { occurrencesForRange, relativeDayLabel } from '../utils/time';
import type { Occurrence, OccurrenceStatus } from '../types';

const FILTERS: {value: 'all' | OccurrenceStatus;label: string;}[] = [
{ value: 'all', label: 'All' },
{ value: 'taken', label: 'Taken' },
{ value: 'missed', label: 'Missed' },
{ value: 'snoozed', label: 'Snoozed' }];


export function CaregiverActivity() {
  const { user } = useAuth();
  const now = useNow(15_000);
  const { patients, loading } = useCaregiverPatients(user?.uid);
  const [filter, setFilter] = useState<'all' | OccurrenceStatus>('all');

  const rows = useMemo(() => {
    const all: {name: string;dose: Occurrence;}[] = [];
    patients.forEach((bundle) => {
      occurrencesForRange(
        bundle.medicines,
        bundle.logs,
        7,
        bundle.settings.gracePeriodMinutes,
        now
      ).forEach((dose) => all.push({ name: bundle.patient.name, dose }));
    });
    return all.sort((a, b) => b.dose.scheduledAt - a.dose.scheduledAt);
  }, [patients, now]);

  const visible = rows.filter(({ dose }) => {
    if (filter === 'all') return true;
    if (filter === 'snoozed') return (dose.log?.snoozeCount ?? 0) > 0;
    return dose.status === filter;
  });

  return (
    <div className="flex flex-col gap-6">
      <SectionHeading
        title="Activity"
        subtitle="Last 7 days of reminder responses across your patients." />
      

      <div className="flex flex-wrap gap-2" role="group" aria-label="Filter activity">
        {FILTERS.map((option) => {
          const active = filter === option.value;
          return (
            <button
              key={option.value}
              type="button"
              onClick={() => setFilter(option.value)}
              aria-pressed={active}
              className={`min-h-[48px] rounded-2xl border px-5 text-base font-bold transition-colors duration-150 ease-out ${
              active ?
              'border-primary-600 bg-primary-600 text-white' :
              'border-line bg-surface text-ink-muted hover:border-primary-300 hover:text-primary-700'}`
              }>
              
              {option.label}
            </button>);

        })}
      </div>

      {loading ?
      <LoadingState label="Loading activity…" /> :
      visible.length === 0 ?
      <EmptyState
        icon={<ActivityIcon className="h-8 w-8" aria-hidden="true" />}
        title="No activity to show yet"
        message="Once a connected patient responds to a reminder, it appears here." /> :


      <ul className="flex flex-col gap-3">
          {visible.map(({ name, dose }) =>
        <DoseRow
          key={`${name}-${dose.key}`}
          occurrence={dose}
          dateLabel={`${name} · ${relativeDayLabel(dose.dateKey)}`} />

        )}
        </ul>
      }

      <Disclaimer />
    </div>);

}