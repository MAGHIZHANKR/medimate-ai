import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { BellIcon, LogOutIcon, Volume2Icon } from 'lucide-react';
import * as db from '../services/db';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { Card, SectionHeading } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input, Select } from '../components/ui/Field';
import { Disclaimer } from '../components/Brand';
import { notificationState, requestNotificationPermission } from '../services/notifications';
import { buildReminderSentence, speak, voiceSupported } from '../services/voice';

const GRACE_OPTIONS = [
{ value: '10', label: '10 minutes' },
{ value: '20', label: '20 minutes' },
{ value: '30', label: '30 minutes' },
{ value: '60', label: '60 minutes' }];


export function Settings() {
  const { user, settings, updateSettings, updateName, signOut } = useAuth();
  const { notify } = useToast();
  const [name, setName] = useState(user?.name ?? '');
  const [savingName, setSavingName] = useState(false);
  const [permission, setPermission] = useState(notificationState());
  const isPatient = user?.role === 'patient';
  const demoLoaded = user ? db.hasDemoData(user.uid) : false;

  return (
    <div className="flex flex-col gap-6">
      <SectionHeading title="Settings" subtitle="Your profile, reminders and access." />

      <Card as="section" aria-labelledby="profile-heading" className="flex flex-col gap-5">
        <h2 id="profile-heading" className="text-xl font-bold text-ink">
          Profile
        </h2>
        <Input
          label="Full name"
          value={name}
          onChange={(event) => setName(event.target.value)}
          autoComplete="name" />
        
        <div>
          <p className="text-base font-semibold text-ink">Email</p>
          <p className="mt-1 text-lg text-ink-muted">{user?.email}</p>
          <p className="mt-3 text-base font-semibold capitalize text-ink">
            Role: <span className="font-normal text-ink-muted">{user?.role}</span>
          </p>
        </div>
        <Button
          className="self-start"
          loading={savingName}
          disabled={!name.trim() || name === user?.name}
          onClick={() => {
            setSavingName(true);
            updateName(name.trim());
            setSavingName(false);
            notify('Profile updated', 'success');
          }}>
          
          {savingName ? 'Saving…' : 'Save profile'}
        </Button>
      </Card>

      <Card as="section" aria-labelledby="reminders-heading" className="flex flex-col gap-6">
        <h2 id="reminders-heading" className="text-xl font-bold text-ink">
          Reminders
        </h2>

        <div className="flex flex-col gap-3 border-b border-line pb-6 sm:flex-row sm:items-center">
          <div className="flex-1">
            <p className="text-lg font-semibold text-ink">System notifications</p>
            <p className="mt-1 text-base text-ink-muted">
              {permission === 'granted' ?
              'Allowed. Reminders appear even when this tab is in the background.' :
              permission === 'denied' ?
              'Blocked in your browser settings. Reminders still appear inside MediMate.' :
              permission === 'unsupported' ?
              'Not supported by this browser. Reminders still appear inside MediMate.' :
              'Not enabled yet.'}
            </p>
          </div>
          {permission === 'default' &&
          <Button
            variant="secondary"
            onClick={async () => {
              const result = await requestNotificationPermission();
              setPermission(result);
              updateSettings({ notificationsAsked: true });
            }}>
            
              <BellIcon className="h-5 w-5" aria-hidden="true" />
              Allow notifications
            </Button>
          }
        </div>

        {isPatient &&
        <>
            <div className="flex flex-col gap-3 border-b border-line pb-6 sm:flex-row sm:items-center">
              <div className="flex-1">
                <p className="text-lg font-semibold text-ink">Voice reminders</p>
                <p className="mt-1 text-base text-ink-muted">
                  {voiceSupported() ?
                'MediMate reads the reminder out loud when it appears.' :
                'Your browser does not support spoken reminders.'}
                </p>
              </div>
              <div className="flex gap-2">
                <Button
                variant="secondary"
                disabled={!settings.voiceEnabled || !voiceSupported()}
                onClick={() => speak(buildReminderSentence('Metformin', '1 tablet', 'after'))}>
                
                  <Volume2Icon className="h-5 w-5" aria-hidden="true" />
                  Test voice
                </Button>
                <Button
                variant={settings.voiceEnabled ? 'primary' : 'secondary'}
                aria-pressed={settings.voiceEnabled}
                onClick={() => updateSettings({ voiceEnabled: !settings.voiceEnabled })}>
                
                  {settings.voiceEnabled ? 'Voice is ON' : 'Voice is OFF'}
                </Button>
              </div>
            </div>

            <Select
            label="Reminder grace period"
            hint="A dose that is not answered within this window is recorded as Missed."
            value={String(settings.gracePeriodMinutes)}
            options={GRACE_OPTIONS}
            onChange={(event) =>
            updateSettings({ gracePeriodMinutes: Number(event.target.value) })
            }
            className="max-w-sm" />
          
          </>
        }
      </Card>

      {isPatient &&
      <Card as="section" aria-labelledby="access-heading" className="flex flex-col gap-4">
          <h2 id="access-heading" className="text-xl font-bold text-ink">
            Caregiver access
          </h2>
          <p className="text-base text-ink-muted">
            Your code is <span className="font-bold text-ink">{user?.caregiverCode}</span>. Approve
            or remove caregivers on the Caregiver page.
          </p>
          <Link
          to="/caregiver"
          className="inline-flex min-h-[48px] w-fit items-center rounded-2xl border border-primary-200 bg-white px-5 text-base font-semibold text-primary-700 transition-colors duration-150 hover:bg-primary-50">
          
            Manage caregiver access
          </Link>
        </Card>
      }

      {isPatient &&
      <Card as="section" aria-labelledby="demo-heading" className="flex flex-col gap-4">
          <h2 id="demo-heading" className="text-xl font-bold text-ink">
            Demo data
          </h2>
          <p className="text-base text-ink-muted">
            Loads three sample medicines — one scheduled a few minutes from now — so a reminder can
            be demonstrated straight away. Demo medicines are labelled and can be removed in one
            click.
          </p>
          <div className="flex flex-wrap gap-2">
            <Button
            variant="secondary"
            onClick={() => {
              if (!user) return;
              db.seedDemoData(user.uid);
              notify('Demo medicines added', 'success');
            }}>
            
              Load demo medicines
            </Button>
            <Button
            variant="danger"
            disabled={!demoLoaded}
            onClick={() => {
              if (!user) return;
              db.clearDemoData(user.uid);
              notify('Demo medicines removed', 'info');
            }}>
            
              Remove demo medicines
            </Button>
          </div>
        </Card>
      }

      <Card as="section" className="flex flex-col gap-4">
        <h2 className="text-xl font-bold text-ink">Account</h2>
        <Button variant="danger" className="self-start" onClick={signOut}>
          <LogOutIcon className="h-5 w-5" aria-hidden="true" />
          Log out
        </Button>
      </Card>

      <Disclaimer />
    </div>);

}