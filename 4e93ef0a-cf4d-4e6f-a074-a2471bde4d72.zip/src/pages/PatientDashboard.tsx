import React from 'react';
import { Link } from 'react-router-dom';
import {
  AlarmClockIcon,
  AlertTriangleIcon,
  CheckIcon,
  ClockIcon,
  PillIcon,
  PlusIcon } from
'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useReminders } from '../contexts/ReminderContext';
import { Card, SectionHeading } from '../components/ui/Card';
import { StatCard } from '../components/ui/StatCard';
import { EmptyState, LoadingState } from '../components/ui/EmptyState';
import { Button } from '../components/ui/Button';
import { Disclaimer } from '../components/Brand';
import { DoseRow } from '../components/DoseRow';
import { NextDoseCard } from '../components/NextDoseCard';
import { WeeklyResponse } from '../components/WeeklyResponse';
import { NotificationPrompt } from '../components/NotificationPrompt';
import { keyToDate } from '../utils/time';

function greeting(now: number): string {
  const hour = new Date(now).getHours();
  if (hour < 12) return 'Good morning';
  if (hour < 17) return 'Good afternoon';
  return 'Good evening';
}

export function PatientDashboard() {
  const { user, settings } = useAuth();
  const {
    now,
    loading,
    medicines,
    logs,
    todaysDoses,
    counts,
    nextDose,
    today,
    markTaken,
    snooze,
    snoozesLeft
  } = useReminders();

  return (
    <div className="flex flex-col gap-7">
      <header>
        <p className="text-base font-semibold text-ink-muted">
          {keyToDate(today).toLocaleDateString(undefined, {
            weekday: 'long',
            day: 'numeric',
            month: 'long'
          })}
        </p>
        <h1 className="mt-1 text-3xl font-extrabold tracking-tight text-ink sm:text-4xl">
          {greeting(now)}, {user?.name.split(' ')[0]} 👋
        </h1>
        <p className="mt-2 text-lg text-ink-muted">Here is your medicine plan for today.</p>
      </header>

      <NotificationPrompt />

      {loading ?
      <LoadingState label="Loading your medicines…" /> :
      medicines.length === 0 ?
      <EmptyState
        icon={<PillIcon className="h-8 w-8 -rotate-45" aria-hidden="true" />}
        title="You're all set! Add your first medicine reminder."
        message="Tell MediMate what you take and when. You'll get a notification, a spoken reminder, and a big button to mark it as taken."
        action={
        <Link
          to="/medicines"
          className="inline-flex min-h-[60px] items-center justify-center gap-2 rounded-2xl border border-primary-600 bg-primary-600 px-7 text-lg font-semibold text-white transition-colors duration-150 ease-out hover:bg-primary-700">
          
              <PlusIcon className="h-5 w-5" aria-hidden="true" />
              Add medicine
            </Link>
        } /> :


      <>
          {nextDose ?
        <NextDoseCard
          dose={nextDose}
          now={now}
          onTaken={() => markTaken(nextDose)}
          onSnooze={() => snooze(nextDose)}
          snoozeDisabled={snoozesLeft(nextDose) <= 0} /> :


        <Card className="border-status-taken/25 bg-status-takenSoft">
              <div className="flex items-center gap-4">
                <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-status-taken text-white">
                  <CheckIcon className="h-8 w-8" strokeWidth={3} aria-hidden="true" />
                </span>
                <div>
                  <p className="text-2xl font-extrabold text-ink">
                    Every dose for today is answered
                  </p>
                  <p className="mt-1 text-base text-ink-muted">
                    Your next reminder starts again tomorrow morning.
                  </p>
                </div>
              </div>
            </Card>
        }

          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            <StatCard
            label="Today's medicines"
            value={todaysDoses.length}
            icon={<PillIcon className="h-6 w-6 -rotate-45" aria-hidden="true" />} />
          
            <StatCard
            label="Taken"
            value={counts.taken}
            tone="taken"
            icon={<CheckIcon className="h-6 w-6" aria-hidden="true" />} />
          
            <StatCard
            label="Upcoming"
            value={counts.upcoming + counts.due + counts.snoozed}
            tone="upcoming"
            icon={<ClockIcon className="h-6 w-6" aria-hidden="true" />} />
          
            <StatCard
            label="Missed"
            value={counts.missed}
            tone="missed"
            icon={<AlertTriangleIcon className="h-6 w-6" aria-hidden="true" />} />
          
          </div>

          <section aria-labelledby="todays-plan-heading">
            <SectionHeading
            title="Today's plan"
            subtitle="Every scheduled dose, in order."
            action={
            <Link
              to="/medicines"
              className="text-base font-bold text-primary-700 underline-offset-4 hover:underline">
              
                  Manage medicines
                </Link>
            } />
          
            <h2 id="todays-plan-heading" className="sr-only">
              Today's plan
            </h2>
            <ul className="flex flex-col gap-3">
              {todaysDoses.map((dose) =>
            <DoseRow
              key={dose.key}
              occurrence={dose}
              actions={
              dose.status === 'taken' ? null :
              <div className="flex gap-2">
                        <Button onClick={() => markTaken(dose)} className="min-h-[44px] px-4">
                          <CheckIcon className="h-5 w-5" aria-hidden="true" />
                          Taken
                        </Button>
                        {(dose.status === 'due' || dose.status === 'snoozed') &&
                <Button
                  variant="secondary"
                  onClick={() => snooze(dose)}
                  disabled={snoozesLeft(dose) <= 0}
                  className="min-h-[44px] px-4"
                  aria-label="Snooze 10 minutes">
                  
                            <AlarmClockIcon className="h-5 w-5" aria-hidden="true" />
                            10 min
                          </Button>
                }
                      </div>

              } />

            )}
            </ul>
          </section>

          <WeeklyResponse
          medicines={medicines}
          logs={logs}
          graceMinutes={settings.gracePeriodMinutes}
          now={now} />
        
        </>
      }

      <Disclaimer />
    </div>);

}