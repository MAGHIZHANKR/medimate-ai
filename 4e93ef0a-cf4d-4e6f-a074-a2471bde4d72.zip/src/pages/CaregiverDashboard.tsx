import React from 'react';
import { Link } from 'react-router-dom';
import { AlertTriangleIcon, CheckIcon, ClockIcon, UsersRoundIcon } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useNow } from '../hooks/useNow';
import { useCaregiverPatients } from '../hooks/useCaregiverPatients';
import { SectionHeading } from '../components/ui/Card';
import { StatCard } from '../components/ui/StatCard';
import { EmptyState, LoadingState } from '../components/ui/EmptyState';
import { Disclaimer } from '../components/Brand';
import { PatientSummaryCard } from '../components/PatientSummaryCard';
import { countByStatus, dateKey, occurrencesForDay } from '../utils/time';

export function CaregiverDashboard() {
  const { user } = useAuth();
  const now = useNow(10_000);
  const { patients, pending, loading } = useCaregiverPatients(user?.uid);

  const today = dateKey(new Date(now));
  const allDoses = patients.flatMap((bundle) =>
  occurrencesForDay(
    bundle.medicines,
    bundle.logs,
    today,
    bundle.settings.gracePeriodMinutes,
    now
  )
  );
  const counts = countByStatus(allDoses);

  return (
    <div className="flex flex-col gap-7">
      <header>
        <h1 className="text-3xl font-extrabold tracking-tight text-ink sm:text-4xl">
          Hello, {user?.name.split(' ')[0]} 👋
        </h1>
        <p className="mt-2 text-lg text-ink-muted">
          Live medicine status for the people you care for.
        </p>
      </header>

      {pending.length > 0 &&
      <p className="rounded-2xl border border-status-upcoming/25 bg-status-upcomingSoft px-4 py-3 text-base font-semibold text-status-upcoming">
          {pending.length === 1 ?
        `Waiting for ${pending[0].patientName} to approve your request.` :
        `${pending.length} connection requests are waiting for approval.`}
        </p>
      }

      {loading ?
      <LoadingState label="Loading patients…" /> :
      patients.length === 0 ?
      <EmptyState
        icon={<UsersRoundIcon className="h-8 w-8" aria-hidden="true" />}
        title="No patient connected yet."
        message="Ask your family member for their 6-character MediMate code, then connect from the Patients page. They approve the request before anything is shared."
        action={
        <Link
          to="/patients"
          className="inline-flex min-h-[60px] items-center rounded-2xl border border-primary-600 bg-primary-600 px-7 text-lg font-semibold text-white transition-colors duration-150 hover:bg-primary-700">
          
              Connect a patient
            </Link>
        } /> :


      <>
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            <StatCard
            label="Doses scheduled today"
            value={allDoses.length}
            icon={<ClockIcon className="h-6 w-6" aria-hidden="true" />} />
          
            <StatCard
            label="Marked taken"
            value={counts.taken}
            tone="taken"
            icon={<CheckIcon className="h-6 w-6" aria-hidden="true" />} />
          
            <StatCard
            label="Still upcoming"
            value={counts.upcoming + counts.due + counts.snoozed}
            tone="upcoming"
            icon={<ClockIcon className="h-6 w-6" aria-hidden="true" />} />
          
            <StatCard
            label="Missed"
            value={counts.missed}
            tone="missed"
            icon={<AlertTriangleIcon className="h-6 w-6" aria-hidden="true" />} />
          
          </div>

          <section aria-labelledby="patients-heading">
            <SectionHeading title="Patients" subtitle="Updates arrive without refreshing." />
            <h2 id="patients-heading" className="sr-only">
              Patients
            </h2>
            <ul className="grid gap-4 xl:grid-cols-2">
              {patients.map((bundle) =>
            <PatientSummaryCard key={bundle.patient.uid} bundle={bundle} now={now} />
            )}
            </ul>
          </section>
        </>
      }

      <Disclaimer />
    </div>);

}