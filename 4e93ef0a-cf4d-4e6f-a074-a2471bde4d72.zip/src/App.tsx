import React from 'react';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { ToastProvider } from './contexts/ToastContext';
import { ReminderProvider } from './contexts/ReminderContext';
import { AuthLayout } from './layouts/AuthLayout';
import { AppLayout } from './layouts/AppLayout';
import { Login } from './pages/Login';
import { Register } from './pages/Register';
import { ForgotPassword } from './pages/ForgotPassword';
import { PatientDashboard } from './pages/PatientDashboard';
import { Medicines } from './pages/Medicines';
import { History } from './pages/History';
import { CaregiverAccess } from './pages/CaregiverAccess';
import { Settings } from './pages/Settings';
import { CaregiverDashboard } from './pages/CaregiverDashboard';
import { CaregiverPatients } from './pages/CaregiverPatients';
import { CaregiverPatientDetail } from './pages/CaregiverPatientDetail';
import { CaregiverActivity } from './pages/CaregiverActivity';
import { Wordmark } from './components/Brand';

function Splash() {
  return (
    <div className="flex min-h-full w-full items-center justify-center bg-canvas px-6">
      <div className="flex flex-col items-center gap-4" role="status" aria-live="polite">
        <Wordmark size="lg" />
        <p className="text-base font-semibold text-ink-muted">Loading MediMate…</p>
      </div>
    </div>);

}

function AppRoutes() {
  const { user, initializing } = useAuth();

  if (initializing) return <Splash />;

  if (!user) {
    return (
      <Routes>
        <Route element={<AuthLayout />}>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/forgot-password" element={<ForgotPassword />} />
        </Route>
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>);

  }

  if (user.role === 'caregiver') {
    return (
      <Routes>
        <Route element={<AppLayout />}>
          <Route path="/dashboard" element={<CaregiverDashboard />} />
          <Route path="/patients" element={<CaregiverPatients />} />
          <Route path="/patients/:patientId" element={<CaregiverPatientDetail />} />
          <Route path="/activity" element={<CaregiverActivity />} />
          <Route path="/settings" element={<Settings />} />
        </Route>
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>);

  }

  return (
    <ReminderProvider>
      <Routes>
        <Route element={<AppLayout />}>
          <Route path="/dashboard" element={<PatientDashboard />} />
          <Route path="/medicines" element={<Medicines />} />
          <Route path="/history" element={<History />} />
          <Route path="/caregiver" element={<CaregiverAccess />} />
          <Route path="/settings" element={<Settings />} />
        </Route>
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </ReminderProvider>);

}

export function App() {
  return (
    <BrowserRouter>
      <ToastProvider>
        <AuthProvider>
          <AppRoutes />
        </AuthProvider>
      </ToastProvider>
    </BrowserRouter>);

}