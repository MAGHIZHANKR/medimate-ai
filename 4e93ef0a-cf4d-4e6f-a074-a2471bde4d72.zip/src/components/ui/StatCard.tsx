import React from 'react';
import { twMerge } from 'tailwind-merge';

interface StatCardProps {
  label: string;
  value: React.ReactNode;
  icon: React.ReactNode;
  tone?: 'neutral' | 'taken' | 'upcoming' | 'missed' | 'snoozed';
  className?: string;
}

const TONES = {
  neutral: 'text-ink bg-primary-50 border-primary-100',
  taken: 'text-status-taken bg-status-takenSoft border-status-taken/20',
  upcoming: 'text-status-upcoming bg-status-upcomingSoft border-status-upcoming/20',
  missed: 'text-status-missed bg-status-missedSoft border-status-missed/20',
  snoozed: 'text-status-snoozed bg-status-snoozedSoft border-status-snoozed/20'
};

export function StatCard({ label, value, icon, tone = 'neutral', className }: StatCardProps) {
  return (
    <div
      className={twMerge(
        'flex items-center gap-4 rounded-2xl border border-line bg-surface px-4 py-4 shadow-card',
        className
      )}>
      
      <span
        className={twMerge(
          'flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border',
          TONES[tone]
        )}
        aria-hidden="true">
        
        {icon}
      </span>
      <span className="min-w-0">
        <span className="block text-3xl font-extrabold leading-none text-ink">{value}</span>
        <span className="mt-1 block text-base font-medium text-ink-muted">{label}</span>
      </span>
    </div>);

}