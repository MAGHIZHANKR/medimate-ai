import React from 'react';
import { twMerge } from 'tailwind-merge';

interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  as?: 'div' | 'section' | 'article' | 'li';
  padded?: boolean;
}

export function Card({
  as = 'div',
  padded = true,
  className,
  children,
  ...rest
}: CardProps) {
  const Tag = as as React.ElementType;
  return (
    <Tag
      {...rest}
      className={twMerge(
        'rounded-2.5xl border border-line bg-surface shadow-card',
        padded && 'p-5 sm:p-6',
        className
      )}>
      
      {children}
    </Tag>);

}

export function SectionHeading({
  title,
  subtitle,
  action




}: {title: string;subtitle?: string;action?: React.ReactNode;}) {
  return (
    <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h2 className="text-xl font-bold tracking-tight text-ink sm:text-2xl">{title}</h2>
        {subtitle && <p className="mt-1 text-base text-ink-muted">{subtitle}</p>}
      </div>
      {action}
    </div>);

}