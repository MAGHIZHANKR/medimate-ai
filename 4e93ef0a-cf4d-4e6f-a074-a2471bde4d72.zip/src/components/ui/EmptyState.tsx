import React from 'react';

export function EmptyState({
  icon,
  title,
  message,
  action





}: {icon: React.ReactNode;title: string;message: string;action?: React.ReactNode;}) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2.5xl border border-dashed border-line bg-surface px-6 py-12 text-center">
      <span
        className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-primary-50 text-primary-600"
        aria-hidden="true">
        
        {icon}
      </span>
      <h3 className="text-xl font-bold text-ink">{title}</h3>
      <p className="mt-2 max-w-md text-base leading-relaxed text-ink-muted">{message}</p>
      {action && <div className="mt-6">{action}</div>}
    </div>);

}

export function LoadingState({ label }: {label: string;}) {
  return (
    <div className="flex flex-col gap-3" role="status" aria-live="polite">
      <p className="text-base font-semibold text-ink-muted">{label}</p>
      {[0, 1, 2].map((index) =>
      <div
        key={index}
        className="h-20 animate-pulse rounded-2xl border border-line bg-surface" />

      )}
    </div>);

}