import React from 'react';
import { twMerge } from 'tailwind-merge';
import { Loader2Icon } from 'lucide-react';

type Variant = 'primary' | 'secondary' | 'ghost' | 'danger' | 'success';
type Size = 'md' | 'lg';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  loading?: boolean;
  fullWidth?: boolean;
}

const VARIANTS: Record<Variant, string> = {
  primary:
  'bg-primary-600 text-white border-primary-600 hover:bg-primary-700 hover:border-primary-700',
  secondary:
  'bg-white text-primary-700 border-primary-200 hover:bg-primary-50 hover:border-primary-300',
  ghost: 'bg-transparent text-ink-muted border-transparent hover:bg-primary-50 hover:text-primary-700',
  danger:
  'bg-white text-status-missed border-status-missed/30 hover:bg-status-missedSoft hover:border-status-missed/50',
  success:
  'bg-status-taken text-white border-status-taken hover:bg-[#116632] hover:border-[#116632]'
};

const SIZES: Record<Size, string> = {
  md: 'min-h-[48px] px-5 text-base',
  lg: 'min-h-[60px] px-7 text-lg'
};

export function Button({
  variant = 'primary',
  size = 'md',
  loading = false,
  fullWidth = false,
  className,
  children,
  disabled,
  ...rest
}: ButtonProps) {
  return (
    <button
      {...rest}
      disabled={disabled || loading}
      className={twMerge(
        'inline-flex items-center justify-center gap-2.5 rounded-2xl border font-semibold transition-[background-color,border-color,color,transform] duration-150 ease-out active:scale-[0.985] disabled:cursor-not-allowed disabled:opacity-55',
        VARIANTS[variant],
        SIZES[size],
        fullWidth && 'w-full',
        className
      )}>
      
      {loading && <Loader2Icon className="h-5 w-5 animate-spin" aria-hidden="true" />}
      {children}
    </button>);

}