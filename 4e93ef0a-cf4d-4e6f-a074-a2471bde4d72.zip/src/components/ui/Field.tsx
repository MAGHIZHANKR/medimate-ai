import React from 'react';
import { twMerge } from 'tailwind-merge';
import { AlertCircleIcon } from 'lucide-react';

const CONTROL =
'w-full min-h-[56px] rounded-2xl border bg-white px-4 text-lg text-ink placeholder:text-ink-subtle transition-colors duration-150 ease-out';

export function FieldShell({
  label,
  htmlFor,
  hint,
  error,
  children,
  className







}: {label: string;htmlFor?: string;hint?: string;error?: string;children: React.ReactNode;className?: string;}) {
  return (
    <div className={twMerge('flex flex-col gap-2', className)}>
      <label htmlFor={htmlFor} className="text-base font-semibold text-ink">
        {label}
      </label>
      {children}
      {hint && !error && <p className="text-sm text-ink-muted">{hint}</p>}
      {error &&
      <p className="flex items-center gap-1.5 text-sm font-semibold text-status-missed">
          <AlertCircleIcon className="h-4 w-4" aria-hidden="true" />
          {error}
        </p>
      }
    </div>);

}

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
  hint?: string;
  error?: string;
}

export function Input({ label, hint, error, className, id, ...rest }: InputProps) {
  const fieldId = id ?? `field-${label.replace(/\s+/g, '-').toLowerCase()}`;
  return (
    <FieldShell label={label} htmlFor={fieldId} hint={hint} error={error} className={className}>
      <input
        {...rest}
        id={fieldId}
        aria-invalid={Boolean(error)}
        className={twMerge(
          CONTROL,
          error ? 'border-status-missed' : 'border-line focus:border-primary-500'
        )} />
      
    </FieldShell>);

}

interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label: string;
  hint?: string;
  error?: string;
  options: {value: string;label: string;}[];
}

export function Select({
  label,
  hint,
  error,
  options,
  className,
  id,
  ...rest
}: SelectProps) {
  const fieldId = id ?? `select-${label.replace(/\s+/g, '-').toLowerCase()}`;
  return (
    <FieldShell label={label} htmlFor={fieldId} hint={hint} error={error} className={className}>
      <select
        {...rest}
        id={fieldId}
        aria-invalid={Boolean(error)}
        className={twMerge(
          CONTROL,
          'pr-10',
          error ? 'border-status-missed' : 'border-line focus:border-primary-500'
        )}>
        
        {options.map((option) =>
        <option key={option.value} value={option.value}>
            {option.label}
          </option>
        )}
      </select>
    </FieldShell>);

}

interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label: string;
  hint?: string;
  error?: string;
}

export function Textarea({ label, hint, error, className, id, ...rest }: TextareaProps) {
  const fieldId = id ?? `textarea-${label.replace(/\s+/g, '-').toLowerCase()}`;
  return (
    <FieldShell label={label} htmlFor={fieldId} hint={hint} error={error} className={className}>
      <textarea
        {...rest}
        id={fieldId}
        className={twMerge(
          CONTROL,
          'min-h-[110px] resize-y py-3 leading-relaxed',
          error ? 'border-status-missed' : 'border-line focus:border-primary-500'
        )} />
      
    </FieldShell>);

}