import React from 'react';
import { AlarmClockIcon, AlertTriangleIcon, CheckIcon, ClockIcon } from 'lucide-react';
import type { OccurrenceStatus } from '../../types';

const CONFIG: Record<
  OccurrenceStatus,
  {label: string;className: string;icon: React.ReactNode;}> =
{
  taken: {
    label: 'Taken',
    className: 'bg-status-takenSoft text-status-taken border-status-taken/25',
    icon: <CheckIcon className="h-4 w-4" aria-hidden="true" />
  },
  snoozed: {
    label: 'Snoozed',
    className: 'bg-status-snoozedSoft text-status-snoozed border-status-snoozed/25',
    icon: <AlarmClockIcon className="h-4 w-4" aria-hidden="true" />
  },
  missed: {
    label: 'Missed',
    className: 'bg-status-missedSoft text-status-missed border-status-missed/25',
    icon: <AlertTriangleIcon className="h-4 w-4" aria-hidden="true" />
  },
  upcoming: {
    label: 'Upcoming',
    className: 'bg-status-upcomingSoft text-status-upcoming border-status-upcoming/25',
    icon: <ClockIcon className="h-4 w-4" aria-hidden="true" />
  },
  due: {
    label: 'Due now',
    className: 'bg-primary-50 text-primary-700 border-primary-300',
    icon: <AlarmClockIcon className="h-4 w-4" aria-hidden="true" />
  }
};

export function StatusBadge({
  status,
  suffix



}: {status: OccurrenceStatus;suffix?: string;}) {
  const config = CONFIG[status];
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-sm font-bold ${config.className}`}>
      
      {config.icon}
      {config.label}
      {suffix && <span className="font-semibold opacity-80">{suffix}</span>}
    </span>);

}

export const STATUS_LABEL = (status: OccurrenceStatus) => CONFIG[status].label;