import React, { useEffect, useRef } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { XIcon } from 'lucide-react';
import { Button } from './Button';

interface ModalProps {
  open: boolean;
  onClose?: () => void;
  title: string;
  description?: string;
  children: React.ReactNode;
  footer?: React.ReactNode;
  size?: 'md' | 'lg';
  dismissible?: boolean;
}

export function Modal({
  open,
  onClose,
  title,
  description,
  children,
  footer,
  size = 'md',
  dismissible = true
}: ModalProps) {
  const panelRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && dismissible) onClose?.();
    };
    document.addEventListener('keydown', onKey);
    panelRef.current?.focus();
    const previous = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = previous;
    };
  }, [open, onClose, dismissible]);

  return (
    <AnimatePresence>
      {open &&
      <div className="fixed inset-0 z-50 flex items-end justify-center p-0 sm:items-center sm:p-6">
          <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.16, ease: 'easeOut' }}
          className="absolute inset-0 bg-ink/45"
          onClick={() => dismissible && onClose?.()}
          aria-hidden="true" />
        
          <motion.div
          ref={panelRef}
          tabIndex={-1}
          role="dialog"
          aria-modal="true"
          aria-label={title}
          initial={{ opacity: 0, y: 18, scale: 0.97 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 12, scale: 0.98 }}
          transition={{ duration: 0.22, ease: [0.23, 1, 0.32, 1] }}
          className={`relative flex max-h-[92vh] w-full flex-col overflow-hidden rounded-t-3xl bg-surface shadow-lift sm:rounded-3xl ${
          size === 'lg' ? 'sm:max-w-2xl' : 'sm:max-w-lg'}`
          }>
          
            <div className="flex items-start justify-between gap-4 border-b border-line px-5 py-4 sm:px-6">
              <div>
                <h2 className="text-xl font-bold tracking-tight text-ink sm:text-2xl">{title}</h2>
                {description && <p className="mt-1 text-base text-ink-muted">{description}</p>}
              </div>
              {dismissible &&
            <Button
              variant="ghost"
              size="md"
              onClick={onClose}
              aria-label="Close dialog"
              className="min-h-[44px] px-3">
              
                  <XIcon className="h-6 w-6" aria-hidden="true" />
                </Button>
            }
            </div>
            <div className="flex-1 overflow-y-auto px-5 py-5 sm:px-6">{children}</div>
            {footer &&
          <div className="border-t border-line bg-canvas px-5 py-4 sm:px-6">{footer}</div>
          }
          </motion.div>
        </div>
      }
    </AnimatePresence>);

}

export function ConfirmDialog({
  open,
  title,
  message,
  confirmLabel = 'Confirm',
  onConfirm,
  onCancel,
  tone = 'primary',
  loading = false









}: {open: boolean;title: string;message: string;confirmLabel?: string;onConfirm: () => void;onCancel: () => void;tone?: 'primary' | 'danger';loading?: boolean;}) {
  return (
    <Modal open={open} onClose={onCancel} title={title}>
      <p className="text-lg leading-relaxed text-ink-muted">{message}</p>
      <div className="mt-6 flex flex-col gap-3 sm:flex-row-reverse">
        <Button
          variant={tone === 'danger' ? 'danger' : 'primary'}
          onClick={onConfirm}
          loading={loading}
          fullWidth>
          
          {confirmLabel}
        </Button>
        <Button variant="secondary" onClick={onCancel} fullWidth>
          Cancel
        </Button>
      </div>
    </Modal>);

}