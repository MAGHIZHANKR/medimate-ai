import React from 'react';
import { CheckIcon, PillIcon } from 'lucide-react';

export function Logo({ size = 'md' }: {size?: 'md' | 'lg';}) {
  const box = size === 'lg' ? 'h-14 w-14' : 'h-11 w-11';
  const pill = size === 'lg' ? 'h-7 w-7' : 'h-6 w-6';
  return (
    <span className={`relative inline-flex ${box} shrink-0`} aria-hidden="true">
      <span
        className={`flex ${box} items-center justify-center rounded-2xl bg-primary-600 text-white`}>
        
        <PillIcon className={`${pill} -rotate-45`} />
      </span>
      <span className="absolute -bottom-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full border-2 border-white bg-mint-500 text-white">
        <CheckIcon className="h-3 w-3" strokeWidth={3.5} />
      </span>
    </span>);

}

export function Wordmark({ size = 'md' }: {size?: 'md' | 'lg';}) {
  return (
    <span className="flex items-center gap-3">
      <Logo size={size} />
      <span className="flex flex-col leading-none">
        <span
          className={`font-extrabold tracking-tight text-ink ${
          size === 'lg' ? 'text-3xl' : 'text-xl'}`
          }>
          
          MEDIMATE
        </span>
        <span
          className={`mt-1 font-medium text-ink-muted ${
          size === 'lg' ? 'text-base' : 'text-xs'}`
          }>
          
          Never miss a medicine moment.
        </span>
      </span>
    </span>);

}

export function Disclaimer({ compact = false }: {compact?: boolean;}) {
  return (
    <p
      className={`rounded-2xl border border-line bg-surface px-4 py-3 text-ink-muted ${
      compact ? 'text-sm' : 'text-sm sm:text-base'}`
      }>
      
      <span className="font-bold text-ink">Reminder tool only.</span> MediMate provides
      reminders and self-reported tracking. It does not provide medical advice, verify that
      medication was actually taken, or replace a healthcare professional.
    </p>);

}