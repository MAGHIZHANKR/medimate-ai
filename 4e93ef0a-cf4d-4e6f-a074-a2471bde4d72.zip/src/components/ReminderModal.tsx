import React from 'react';
import { AlarmClockIcon, CheckIcon, PillIcon, UtensilsIcon, XIcon, Volume2Icon } from 'lucide-react';
import type { Occurrence } from '../types';
import { FOOD_LABEL, formatTime } from '../utils/time';
import { Modal } from './ui/Modal';
import { Button } from './ui/Button';

export function ReminderModal({
  occurrence,
  snoozesLeft,
  voiceOn,
  onRepeatVoice,
  onTaken,
  onSnooze,
  onMissed,
  busy









}: {occurrence: Occurrence | null;snoozesLeft: number;voiceOn: boolean;onRepeatVoice: () => void;onTaken: () => void;onSnooze: () => void;onMissed: () => void;busy: boolean;}) {
  if (!occurrence) return null;
  const { medicine } = occurrence;

  return (
    <Modal open title="Medicine time" dismissible={false} size="lg">
      <div className="flex flex-col items-center text-center">
        <span className="flex h-20 w-20 items-center justify-center rounded-3xl bg-primary-600 text-white">
          <PillIcon className="h-10 w-10 -rotate-45" aria-hidden="true" />
        </span>
        <p className="mt-5 text-4xl font-extrabold tracking-tight text-ink sm:text-5xl">
          {medicine.name}
        </p>
        <p className="mt-2 text-2xl font-semibold text-ink-muted">{medicine.dosage}</p>
        <div className="mt-3 flex flex-wrap items-center justify-center gap-x-5 gap-y-2 text-lg text-ink-muted">
          <span className="font-bold text-ink">{formatTime(occurrence.scheduledTime)}</span>
          {medicine.foodInstruction !== 'none' &&
          <span className="flex items-center gap-2">
              <UtensilsIcon className="h-5 w-5" aria-hidden="true" />
              {FOOD_LABEL[medicine.foodInstruction]}
            </span>
          }
        </div>
        {medicine.notes &&
        <p className="mt-4 max-w-md rounded-2xl bg-canvas px-4 py-3 text-base text-ink-muted">
            {medicine.notes}
          </p>
        }

        <div className="mt-7 flex w-full flex-col gap-3">
          <Button size="lg" variant="success" onClick={onTaken} loading={busy} fullWidth>
            <CheckIcon className="h-6 w-6" aria-hidden="true" />
            Taken
          </Button>
          <div className="flex flex-col gap-3 sm:flex-row">
            <Button
              size="lg"
              variant="secondary"
              onClick={onSnooze}
              disabled={busy || snoozesLeft <= 0}
              fullWidth>
              
              <AlarmClockIcon className="h-6 w-6" aria-hidden="true" />
              Snooze 10 min
            </Button>
            <Button size="lg" variant="danger" onClick={onMissed} disabled={busy} fullWidth>
              <XIcon className="h-6 w-6" aria-hidden="true" />
              Mark missed
            </Button>
          </div>
        </div>

        <div className="mt-5 flex flex-col items-center gap-2">
          {snoozesLeft <= 0 &&
          <p className="text-sm font-semibold text-status-snoozed">
              Snooze limit reached for this dose — please choose Taken or Mark missed.
            </p>
          }
          {voiceOn &&
          <button
            type="button"
            onClick={onRepeatVoice}
            className="inline-flex items-center gap-2 rounded-full px-3 py-2 text-base font-semibold text-primary-700 transition-colors duration-150 hover:bg-primary-50">
            
              <Volume2Icon className="h-5 w-5" aria-hidden="true" />
              Say it again
            </button>
          }
          <p className="max-w-md text-sm text-ink-subtle">
            Marking “Taken” records your own response. MediMate cannot verify that medicine was
            actually taken.
          </p>
        </div>
      </div>
    </Modal>);

}