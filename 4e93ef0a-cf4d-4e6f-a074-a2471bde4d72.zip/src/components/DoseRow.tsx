import React from 'react';
import { PillIcon, UtensilsIcon } from 'lucide-react';
import type { Occurrence } from '../types';
import { FOOD_LABEL, formatClock, formatTime } from '../utils/time';
import { StatusBadge } from './ui/StatusBadge';

/** One scheduled dose, used in today's plan, history and caregiver views. */
export function DoseRow({
  occurrence,
  actions,
  dateLabel




}: {occurrence: Occurrence;actions?: React.ReactNode;dateLabel?: string;}) {
  const { medicine, status, log } = occurrence;
  const accent =
  status === 'taken' ?
  'border-l-status-taken' :
  status === 'missed' ?
  'border-l-status-missed' :
  status === 'snoozed' ?
  'border-l-status-snoozed' :
  status === 'due' ?
  'border-l-primary-500' :
  'border-l-status-upcoming';

  return (
    <li
      className={`flex flex-col gap-3 border-l-4 ${accent} rounded-2xl border border-line bg-surface p-4 shadow-card sm:flex-row sm:items-center sm:gap-5`}>
      
      <div className="flex w-full min-w-0 items-start gap-4 sm:w-auto sm:flex-1">
        <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary-50 text-primary-600">
          <PillIcon className="h-6 w-6 -rotate-45" aria-hidden="true" />
        </span>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
            <p className="text-xl font-bold leading-tight text-ink">{medicine.name}</p>
            <p className="text-base font-semibold text-ink-muted">{medicine.dosage}</p>
          </div>
          <div className="mt-1 flex flex-wrap items-center gap-x-4 gap-y-1 text-base text-ink-muted">
            <span className="font-semibold text-ink">
              {dateLabel ? `${dateLabel}, ` : ''}
              {formatTime(occurrence.scheduledTime)}
            </span>
            {medicine.foodInstruction !== 'none' &&
            <span className="flex items-center gap-1.5">
                <UtensilsIcon className="h-4 w-4" aria-hidden="true" />
                {FOOD_LABEL[medicine.foodInstruction]}
              </span>
            }
            {status === 'taken' && log && <span>Responded {formatClock(log.actionTime)}</span>}
            {status === 'snoozed' && log?.snoozeUntil &&
            <span className="font-semibold text-status-snoozed">
                Snoozed until {formatClock(log.snoozeUntil)}
              </span>
            }
          </div>
        </div>
      </div>
      <div className="flex flex-wrap items-center gap-2 sm:justify-end">
        <StatusBadge status={status} />
        {actions}
      </div>
    </li>);

}