import React from 'react';
import { AlarmClockIcon, CheckIcon, PillIcon, UtensilsIcon } from 'lucide-react';
import type { Occurrence } from '../types';
import { FOOD_LABEL, formatClock, formatTime } from '../utils/time';
import { Button } from './ui/Button';

function countdown(target: number, now: number): string {
  const diff = Math.round((target - now) / 60_000);
  if (diff <= 0) return 'Due now';
  if (diff < 60) return `in ${diff} min`;
  const hours = Math.floor(diff / 60);
  const minutes = diff % 60;
  return minutes ? `in ${hours} hr ${minutes} min` : `in ${hours} hr`;
}

export function NextDoseCard({
  dose,
  now,
  onTaken,
  onSnooze,
  snoozeDisabled






}: {dose: Occurrence;now: number;onTaken: () => void;onSnooze: () => void;snoozeDisabled: boolean;}) {
  const { medicine } = dose;
  const snoozed = dose.status === 'snoozed';

  return (
    <section
      aria-labelledby="next-dose-heading"
      className="rounded-2.5xl bg-primary-700 p-6 text-white shadow-lift sm:p-8">
      
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2
          id="next-dose-heading"
          className="text-sm font-bold uppercase tracking-[0.14em] text-primary-100">
          
          Next medicine
        </h2>
        <span className="rounded-full bg-primary-600 px-3 py-1.5 text-base font-bold text-white">
          {snoozed && dose.log?.snoozeUntil ?
          `Snoozed until ${formatClock(dose.log.snoozeUntil)}` :
          countdown(dose.effectiveAt, now)}
        </span>
      </div>

      <div className="mt-5 flex flex-col gap-6 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-start gap-5">
          <span className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-primary-600">
            <PillIcon className="h-9 w-9 -rotate-45" aria-hidden="true" />
          </span>
          <div>
            <p className="text-4xl font-extrabold leading-tight tracking-tight sm:text-5xl">
              {medicine.name}
            </p>
            <p className="mt-2 text-xl font-semibold text-primary-100">{medicine.dosage}</p>
            <div className="mt-2 flex flex-wrap items-center gap-x-5 gap-y-1 text-lg text-primary-100">
              <span className="font-bold text-white">{formatTime(dose.scheduledTime)}</span>
              {medicine.foodInstruction !== 'none' &&
              <span className="flex items-center gap-2">
                  <UtensilsIcon className="h-5 w-5" aria-hidden="true" />
                  {FOOD_LABEL[medicine.foodInstruction]}
                </span>
              }
            </div>
          </div>
        </div>

        <div className="flex w-full flex-col gap-3 sm:w-auto sm:min-w-[240px]">
          <Button
            size="lg"
            variant="success"
            onClick={onTaken}
            fullWidth
            className="border-white bg-white text-primary-700 hover:bg-primary-50 hover:border-primary-50">
            
            <CheckIcon className="h-6 w-6" aria-hidden="true" />
            Take medicine
          </Button>
          <Button
            size="lg"
            variant="ghost"
            onClick={onSnooze}
            disabled={snoozeDisabled}
            fullWidth
            className="border-primary-400 text-white hover:bg-primary-600 hover:text-white">
            
            <AlarmClockIcon className="h-6 w-6" aria-hidden="true" />
            +10 min snooze
          </Button>
        </div>
      </div>
    </section>);

}