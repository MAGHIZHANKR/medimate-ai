import React, { useState } from 'react';
import { BellIcon, BellOffIcon } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { Button } from './ui/Button';
import { notificationState, requestNotificationPermission } from '../services/notifications';

/** Asks once, never blocks the app: in-app reminders work regardless. */
export function NotificationPrompt() {
  const { settings, updateSettings } = useAuth();
  const { notify } = useToast();
  const [state, setState] = useState(notificationState());
  const [asking, setAsking] = useState(false);

  if (state === 'granted') return null;

  if (state === 'denied' || state === 'unsupported') {
    return (
      <div className="flex flex-wrap items-center gap-3 rounded-2xl border border-status-snoozed/25 bg-status-snoozedSoft px-4 py-3">
        <BellOffIcon className="h-5 w-5 shrink-0 text-status-snoozed" aria-hidden="true" />
        <p className="flex-1 text-base font-semibold text-status-snoozed">
          {state === 'denied' ?
          'System notifications are blocked in your browser settings. MediMate will still show and speak reminders while this tab is open.' :
          'This browser does not support system notifications. MediMate will still show and speak reminders while this tab is open.'}
        </p>
      </div>);

  }

  if (settings.notificationsAsked) return null;

  return (
    <div className="flex flex-col gap-4 rounded-2xl border border-primary-200 bg-primary-50 px-4 py-4 sm:flex-row sm:items-center">
      <BellIcon className="h-6 w-6 shrink-0 text-primary-700" aria-hidden="true" />
      <p className="flex-1 text-base font-semibold text-primary-800">
        Allow MediMate to send medicine reminders?
      </p>
      <div className="flex flex-col gap-2 sm:flex-row">
        <Button
          loading={asking}
          onClick={async () => {
            setAsking(true);
            const result = await requestNotificationPermission();
            setState(result);
            updateSettings({ notificationsAsked: true });
            setAsking(false);
            notify(
              result === 'granted' ?
              'Notifications are on.' :
              'No problem — reminders will show inside the app.',
              result === 'granted' ? 'success' : 'info'
            );
          }}>
          
          Allow notifications
        </Button>
        <Button variant="secondary" onClick={() => updateSettings({ notificationsAsked: true })}>
          Maybe later
        </Button>
      </div>
    </div>);

}