import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronRightIcon, UserRoundIcon } from 'lucide-react';
import type { PatientBundle } from '../hooks/useCaregiverPatients';
import { countByStatus, dateKey, formatTime, occurrencesForDay } from '../utils/time';
import { Card } from './ui/Card';
import { StatusBadge } from './ui/StatusBadge';

export function PatientSummaryCard({
  bundle,
  now



}: {bundle: PatientBundle;now: number;}) {
  const today = dateKey(new Date(now));
  const doses = occurrencesForDay(
    bundle.medicines,
    bundle.logs,
    today,
    bundle.settings.gracePeriodMinutes,
    now
  );
  const counts = countByStatus(doses);
  const nextDose = doses.find((dose) => dose.status !== 'taken' && dose.status !== 'missed');

  return (
    <Card as="li" className="flex flex-col gap-5">
      <div className="flex items-center gap-4">
        <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-primary-50 text-primary-600">
          <UserRoundIcon className="h-7 w-7" aria-hidden="true" />
        </span>
        <div className="min-w-0 flex-1">
          <h3 className="text-2xl font-bold text-ink">{bundle.patient.name}</h3>
          <p className="text-base text-ink-muted">
            {doses.length} scheduled today
            {nextDose ?
            ` · next at ${formatTime(nextDose.scheduledTime)}` :
            ' · all doses answered'}
          </p>
        </div>
        {counts.missed > 0 ?
        <StatusBadge status="missed" suffix={`${counts.missed}`} /> :

        <StatusBadge status="taken" suffix={`${counts.taken}/${doses.length}`} />
        }
      </div>

      <dl className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        {[
        ['Scheduled', doses.length, 'text-ink'],
        ['Taken', counts.taken, 'text-status-taken'],
        ['Upcoming', counts.upcoming + counts.due + counts.snoozed, 'text-status-upcoming'],
        ['Missed', counts.missed, 'text-status-missed']].
        map(([label, value, tone]) =>
        <div key={label as string} className="rounded-2xl border border-line bg-canvas px-4 py-3">
            <dt className="text-sm font-semibold text-ink-muted">{label}</dt>
            <dd className={`text-2xl font-extrabold ${tone as string}`}>{value as number}</dd>
          </div>
        )}
      </dl>

      <Link
        to={`/patients/${bundle.patient.uid}`}
        className="mt-auto inline-flex min-h-[52px] items-center justify-between gap-2 rounded-2xl border border-primary-200 bg-white px-5 text-lg font-semibold text-primary-700 transition-colors duration-150 ease-out hover:bg-primary-50">
        
        View details
        <ChevronRightIcon className="h-5 w-5" aria-hidden="true" />
      </Link>
    </Card>);

}