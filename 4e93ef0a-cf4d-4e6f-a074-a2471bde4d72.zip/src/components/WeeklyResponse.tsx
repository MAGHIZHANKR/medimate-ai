import React, { useMemo } from 'react';
import type { Medicine, MedicineLog } from '../types';
import {
  addDays,
  countByStatus,
  dateKey,
  keyToDate,
  occurrencesForDay,
  responseRate } from
'../utils/time';
import { Card, SectionHeading } from './ui/Card';

function Ring({ value }: {value: number;}) {
  const radius = 52;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - Math.min(value, 100) / 100 * circumference;
  return (
    <svg viewBox="0 0 128 128" className="h-32 w-32 shrink-0" role="img" aria-label={`${value}% of reminders marked taken`}>
      <circle cx="64" cy="64" r={radius} fill="none" stroke="#e4eeee" strokeWidth="12" />
      <circle
        cx="64"
        cy="64"
        r={radius}
        fill="none"
        stroke="#166b6f"
        strokeWidth="12"
        strokeLinecap="round"
        strokeDasharray={circumference}
        strokeDashoffset={offset}
        transform="rotate(-90 64 64)"
        style={{ transition: 'stroke-dashoffset 300ms cubic-bezier(0.23,1,0.32,1)' }} />
      
      <text
        x="64"
        y="62"
        textAnchor="middle"
        className="fill-ink"
        style={{ fontSize: 26, fontWeight: 800 }}>
        
        {value}%
      </text>
      <text
        x="64"
        y="82"
        textAnchor="middle"
        className="fill-ink-muted"
        style={{ fontSize: 12, fontWeight: 600 }}>
        
        marked taken
      </text>
    </svg>);

}

export function WeeklyResponse({
  medicines,
  logs,
  graceMinutes,
  now





}: {medicines: Medicine[];logs: MedicineLog[];graceMinutes: number;now: number;}) {
  const days = useMemo(() => {
    const today = dateKey(new Date(now));
    return Array.from({ length: 7 }, (_, index) => {
      const key = addDays(today, -(6 - index));
      const doses = occurrencesForDay(medicines, logs, key, graceMinutes, now);
      return { key, doses, counts: countByStatus(doses) };
    });
  }, [medicines, logs, graceMinutes, now]);

  const all = days.flatMap((day) => day.doses);
  const totals = countByStatus(all);
  const rate = responseRate(all);
  const maxDoses = Math.max(1, ...days.map((day) => day.doses.length));

  return (
    <Card as="section" aria-labelledby="weekly-response-heading">
      <SectionHeading
        title="Weekly reminder response"
        subtitle={`${rate}% of scheduled reminders in the last 7 days were marked Taken.`} />
      
      <h3 id="weekly-response-heading" className="sr-only">
        Weekly reminder response rate
      </h3>

      <div className="flex flex-col gap-7 lg:flex-row lg:items-center">
        <div className="flex items-center gap-5">
          <Ring value={rate} />
          <dl className="grid gap-2.5">
            {[
            ['Taken', totals.taken, 'text-status-taken'],
            ['Snoozed', totals.snoozed, 'text-status-snoozed'],
            ['Missed', totals.missed, 'text-status-missed']].
            map(([label, value, tone]) =>
            <div key={label as string} className="flex items-baseline gap-2">
                <dt className="w-20 text-base font-semibold text-ink-muted">{label}</dt>
                <dd className={`text-2xl font-extrabold ${tone as string}`}>{value as number}</dd>
              </div>
            )}
          </dl>
        </div>

        <ul className="flex flex-1 items-end justify-between gap-2 border-l-0 pt-2 lg:border-l lg:border-line lg:pl-8">
          {days.map((day) => {
            const height = (count: number) => `${count / maxDoses * 100}%`;
            return (
              <li key={day.key} className="flex w-full flex-col items-center gap-2">
                <div className="flex h-28 w-full max-w-[38px] flex-col justify-end gap-1">
                  {day.counts.missed > 0 &&
                  <span
                    className="w-full rounded-md bg-status-missed"
                    style={{ height: height(day.counts.missed) }} />

                  }
                  {day.counts.snoozed > 0 &&
                  <span
                    className="w-full rounded-md bg-status-snoozed"
                    style={{ height: height(day.counts.snoozed) }} />

                  }
                  {day.counts.taken > 0 &&
                  <span
                    className="w-full rounded-md bg-status-taken"
                    style={{ height: height(day.counts.taken) }} />

                  }
                  {day.doses.length === 0 &&
                  <span className="h-1.5 w-full rounded-md bg-line" />
                  }
                </div>
                <span className="text-sm font-semibold text-ink-muted">
                  {keyToDate(day.key).toLocaleDateString(undefined, { weekday: 'narrow' })}
                </span>
              </li>);

          })}
        </ul>
      </div>

      <p className="mt-6 text-sm text-ink-subtle">
        This is a reminder response rate based on what was reported in the app. It is not a measure
        of treatment success.
      </p>
    </Card>);

}