import React, { useState } from 'react';
import { SparklesIcon } from 'lucide-react';
import { Modal } from './ui/Modal';
import { Button } from './ui/Button';
import { Textarea } from './ui/Field';
import { FOOD_LABEL, FREQUENCY_LABEL, formatTime } from '../utils/time';
import {
  aiConfigured,
  parseReminderText,
  type ParsedReminder } from
'../services/aiParser';

const EXAMPLES = [
'Remind me to take my BP tablet every morning after breakfast at 8.',
'Two paracetamol tablets twice daily at 9am and 9pm with food.'];


export function AiReminderModal({
  open,
  onClose,
  onAccept




}: {open: boolean;onClose: () => void;onAccept: (parsed: ParsedReminder) => void;}) {
  const [text, setText] = useState('');
  const [result, setResult] = useState<ParsedReminder | null>(null);
  const [source, setSource] = useState<'gemini' | 'local'>('local');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const reset = () => {
    setText('');
    setResult(null);
    setError('');
  };

  const run = async () => {
    setLoading(true);
    setError('');
    setResult(null);
    const parsed = await parseReminderText(text);
    if (parsed.ok) {
      setResult(parsed.value);
      setSource(parsed.source);
    } else {
      setError(parsed.message);
    }
    setLoading(false);
  };

  return (
    <Modal
      open={open}
      onClose={() => {
        reset();
        onClose();
      }}
      title="Create reminder with AI"
      description="Describe the schedule in your own words. You always review it before saving."
      size="lg">
      
      <Textarea
        label="What should MediMate remind you about?"
        value={text}
        onChange={(event) => setText(event.target.value)}
        placeholder={EXAMPLES[0]}
        hint={aiConfigured() ? undefined : 'Running on the built-in offline parser.'} />
      

      <div className="mt-3 flex flex-wrap gap-2">
        {EXAMPLES.map((example) =>
        <button
          key={example}
          type="button"
          onClick={() => setText(example)}
          className="rounded-full border border-line bg-canvas px-3 py-2 text-sm font-semibold text-ink-muted transition-colors duration-150 hover:border-primary-300 hover:text-primary-700">
          
            Try: “{example.slice(0, 34)}…”
          </button>
        )}
      </div>

      <Button
        className="mt-5"
        size="lg"
        onClick={run}
        loading={loading}
        disabled={!text.trim()}
        fullWidth>
        
        <SparklesIcon className="h-5 w-5" aria-hidden="true" />
        {loading ? 'Reading your sentence…' : 'Convert to reminder'}
      </Button>

      {error &&
      <div
        role="alert"
        className="mt-5 rounded-2xl border border-status-snoozed/30 bg-status-snoozedSoft px-4 py-4">
        
          <p className="text-base font-bold text-status-snoozed">{error}</p>
          <p className="mt-1 text-sm text-ink-muted">
            MediMate never guesses a medicine name, dosage or time.
          </p>
        </div>
      }

      {result &&
      <div className="mt-6 rounded-2.5xl border border-line bg-canvas p-5">
          <p className="text-base font-bold text-ink">Review before saving</p>
          <dl className="mt-4 grid gap-3 sm:grid-cols-2">
            {[
          ['Medicine', result.name || '—'],
          ['Dosage', result.dosage || 'Not detected — add it manually'],
          ['Times', result.times.map(formatTime).join(', ')],
          ['Frequency', FREQUENCY_LABEL[result.frequency]],
          ['Food instruction', FOOD_LABEL[result.foodInstruction]]].
          map(([label, value]) =>
          <div key={label} className="rounded-2xl border border-line bg-surface px-4 py-3">
                <dt className="text-sm font-semibold text-ink-muted">{label}</dt>
                <dd className="mt-0.5 text-lg font-bold text-ink">{value}</dd>
              </div>
          )}
          </dl>
          <p className="mt-4 text-sm text-ink-subtle">
            Read from your sentence by the {source === 'gemini' ? 'Gemini' : 'built-in'} parser.
            Nothing is saved until you confirm. MediMate never recommends medicines or dosages.
          </p>
          <div className="mt-5 flex flex-col gap-3 sm:flex-row-reverse">
            <Button
            size="lg"
            fullWidth
            onClick={() => {
              onAccept(result);
              reset();
            }}>
            
              Continue to form
            </Button>
            <Button variant="secondary" size="lg" fullWidth onClick={() => setResult(null)}>
              Try again
            </Button>
          </div>
        </div>
      }
    </Modal>);

}