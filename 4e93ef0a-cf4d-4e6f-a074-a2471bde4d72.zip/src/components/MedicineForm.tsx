import React, { useEffect, useMemo, useState } from 'react';
import { PlusIcon, Trash2Icon } from 'lucide-react';
import * as db from '../services/db';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { Modal } from './ui/Modal';
import { Button } from './ui/Button';
import { FieldShell, Input, Select, Textarea } from './ui/Field';
import { dateKey, defaultTimesFor, timesCountFor } from '../utils/time';
import type { FoodInstruction, Frequency, Medicine } from '../types';
import type { ParsedReminder } from '../services/aiParser';

const FREQUENCY_OPTIONS: {value: Frequency;label: string;}[] = [
{ value: 'once', label: 'Once only' },
{ value: 'daily', label: 'Daily' },
{ value: 'twice', label: 'Twice daily' },
{ value: 'three', label: 'Three times daily' },
{ value: 'custom', label: 'Custom times' }];


const FOOD_OPTIONS: {value: FoodInstruction;label: string;}[] = [
{ value: 'after', label: 'After food' },
{ value: 'before', label: 'Before food' },
{ value: 'with', label: 'With food' },
{ value: 'none', label: 'No instruction' }];


interface FormState {
  name: string;
  dosage: string;
  times: string[];
  frequency: Frequency;
  foodInstruction: FoodInstruction;
  startDate: string;
  endDate: string;
  notes: string;
}

function initialState(medicine?: Medicine | null, prefill?: ParsedReminder | null): FormState {
  const today = dateKey(new Date());
  if (medicine) {
    return {
      name: medicine.name,
      dosage: medicine.dosage,
      times: [...medicine.times],
      frequency: medicine.frequency,
      foodInstruction: medicine.foodInstruction,
      startDate: medicine.startDate,
      endDate: medicine.endDate ?? '',
      notes: medicine.notes
    };
  }
  return {
    name: prefill?.name ?? '',
    dosage: prefill?.dosage ?? '',
    times: prefill?.times?.length ? [...prefill.times] : ['08:00'],
    frequency: prefill?.frequency ?? 'daily',
    foodInstruction: prefill?.foodInstruction ?? 'after',
    startDate: today,
    endDate: '',
    notes: prefill?.notes ?? ''
  };
}

export function MedicineForm({
  open,
  onClose,
  medicine,
  prefill,
  reviewNotice






}: {open: boolean;onClose: () => void;medicine?: Medicine | null;prefill?: ParsedReminder | null;reviewNotice?: string;}) {
  const { user } = useAuth();
  const { notify } = useToast();
  const [form, setForm] = useState<FormState>(() => initialState(medicine, prefill));
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      setForm(initialState(medicine, prefill));
      setErrors({});
    }
  }, [open, medicine, prefill]);

  const requiredTimes = useMemo(
    () => form.frequency === 'custom' ? form.times.length : timesCountFor(form.frequency),
    [form.frequency, form.times.length]
  );

  const setFrequency = (frequency: Frequency) => {
    setForm((current) => {
      if (frequency === 'custom') return { ...current, frequency };
      const defaults = defaultTimesFor(frequency);
      const times = defaults.map((fallback, index) => current.times[index] ?? fallback);
      return { ...current, frequency, times };
    });
  };

  const setTime = (index: number, value: string) => {
    setForm((current) => {
      const times = [...current.times];
      times[index] = value;
      return { ...current, times };
    });
  };

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    const next: Record<string, string> = {};
    if (!form.name.trim()) next.name = 'Medicine name is required.';
    if (!form.dosage.trim()) next.dosage = 'Add the dosage, for example 1 tablet.';
    if (form.times.some((time) => !/^\d{2}:\d{2}$/.test(time))) next.times = 'Set every dose time.';
    if (new Set(form.times).size !== form.times.length) next.times = 'Dose times must be different.';
    if (!form.startDate) next.startDate = 'Choose a start date.';
    if (form.endDate && form.endDate < form.startDate)
    next.endDate = 'End date cannot be before the start date.';
    setErrors(next);
    if (Object.keys(next).length || !user) return;

    setSaving(true);
    try {
      const payload = {
        name: form.name.trim(),
        dosage: form.dosage.trim(),
        times: [...form.times].sort(),
        frequency: form.frequency,
        foodInstruction: form.foodInstruction,
        startDate: form.startDate,
        endDate: form.endDate || null,
        notes: form.notes.trim()
      };
      if (medicine) {
        db.updateMedicine(medicine.id, { ...payload, demo: false });
        notify(`${payload.name} updated`, 'success');
      } else {
        db.addMedicine(user.uid, payload);
        notify(`${payload.name} added to your plan`, 'success');
      }
      onClose();
    } catch {
      notify('We could not save this medicine. Please try again.', 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal
      open={open}
      onClose={saving ? undefined : onClose}
      title={medicine ? 'Edit medicine' : 'Add medicine'}
      description={
      reviewNotice ?? 'Enter what your prescription says. MediMate only sets up the reminder.'
      }
      size="lg">
      
      {reviewNotice &&
      <p className="mb-5 rounded-2xl border border-status-upcoming/25 bg-status-upcomingSoft px-4 py-3 text-base font-semibold text-status-upcoming">
          Review before saving — nothing is stored until you press Save medicine.
        </p>
      }

      <form id="medicine-form" className="flex flex-col gap-5" onSubmit={submit} noValidate>
        <Input
          label="Medicine name"
          value={form.name}
          error={errors.name}
          onChange={(event) => setForm((c) => ({ ...c, name: event.target.value }))}
          placeholder="Metformin" />
        
        <div className="grid gap-5 sm:grid-cols-2">
          <Input
            label="Dosage"
            value={form.dosage}
            error={errors.dosage}
            onChange={(event) => setForm((c) => ({ ...c, dosage: event.target.value }))}
            placeholder="1 tablet" />
          
          <Select
            label="Frequency"
            value={form.frequency}
            options={FREQUENCY_OPTIONS}
            onChange={(event) => setFrequency(event.target.value as Frequency)} />
          
        </div>

        <FieldShell
          label={requiredTimes > 1 ? 'Dose times' : 'Dose time'}
          error={errors.times}
          hint="Reminders ring at these times every scheduled day.">
          
          <div className="flex flex-col gap-3">
            {form.times.map((time, index) =>
            <div key={index} className="flex items-center gap-3">
                <input
                type="time"
                value={time}
                aria-label={`Dose time ${index + 1}`}
                onChange={(event) => setTime(index, event.target.value)}
                className="min-h-[56px] w-full rounded-2xl border border-line bg-white px-4 text-lg text-ink transition-colors duration-150 focus:border-primary-500" />
              
                {form.frequency === 'custom' && form.times.length > 1 &&
              <Button
                type="button"
                variant="danger"
                onClick={() =>
                setForm((c) => ({ ...c, times: c.times.filter((_, i) => i !== index) }))
                }
                aria-label={`Remove dose time ${index + 1}`}
                className="min-h-[56px] px-4">
                
                    <Trash2Icon className="h-5 w-5" aria-hidden="true" />
                  </Button>
              }
              </div>
            )}
            {form.frequency === 'custom' && form.times.length < 6 &&
            <Button
              type="button"
              variant="secondary"
              onClick={() => setForm((c) => ({ ...c, times: [...c.times, '12:00'] }))}>
              
                <PlusIcon className="h-5 w-5" aria-hidden="true" />
                Add another time
              </Button>
            }
          </div>
        </FieldShell>

        <Select
          label="Food instruction"
          value={form.foodInstruction}
          options={FOOD_OPTIONS}
          onChange={(event) =>
          setForm((c) => ({ ...c, foodInstruction: event.target.value as FoodInstruction }))
          } />
        

        <div className="grid gap-5 sm:grid-cols-2">
          <Input
            label="Start date"
            type="date"
            value={form.startDate}
            error={errors.startDate}
            onChange={(event) => setForm((c) => ({ ...c, startDate: event.target.value }))} />
          
          <Input
            label="End date (optional)"
            type="date"
            value={form.endDate}
            error={errors.endDate}
            onChange={(event) => setForm((c) => ({ ...c, endDate: event.target.value }))}
            hint="Leave empty for ongoing medicines." />
          
        </div>

        <Textarea
          label="Notes (optional)"
          value={form.notes}
          onChange={(event) => setForm((c) => ({ ...c, notes: event.target.value }))}
          placeholder="Take with a full glass of water." />
        
      </form>

      <div className="mt-7 flex flex-col gap-3 sm:flex-row-reverse">
        <Button type="submit" form="medicine-form" size="lg" loading={saving} fullWidth>
          {saving ? 'Saving…' : 'Save medicine'}
        </Button>
        <Button variant="secondary" size="lg" onClick={onClose} disabled={saving} fullWidth>
          Cancel
        </Button>
      </div>
    </Modal>);

}