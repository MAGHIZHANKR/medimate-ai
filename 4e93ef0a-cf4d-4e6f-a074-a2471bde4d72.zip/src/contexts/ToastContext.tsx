import React, { createContext, useCallback, useContext, useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { AlertTriangleIcon, CheckCircle2Icon, InfoIcon, XIcon } from 'lucide-react';

type ToastTone = 'success' | 'error' | 'info';

interface Toast {
  id: number;
  message: string;
  tone: ToastTone;
}

interface ToastValue {
  notify: (message: string, tone?: ToastTone) => void;
}

const ToastContext = createContext<ToastValue | null>(null);

const TONE_STYLES: Record<ToastTone, {bg: string;icon: React.ReactNode;}> = {
  success: {
    bg: 'bg-status-takenSoft border-status-taken/30 text-status-taken',
    icon: <CheckCircle2Icon className="h-6 w-6 shrink-0" aria-hidden="true" />
  },
  error: {
    bg: 'bg-status-missedSoft border-status-missed/30 text-status-missed',
    icon: <AlertTriangleIcon className="h-6 w-6 shrink-0" aria-hidden="true" />
  },
  info: {
    bg: 'bg-status-upcomingSoft border-status-upcoming/30 text-status-upcoming',
    icon: <InfoIcon className="h-6 w-6 shrink-0" aria-hidden="true" />
  }
};

export function ToastProvider({ children }: {children: React.ReactNode;}) {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const dismiss = useCallback((id: number) => {
    setToasts((current) => current.filter((toast) => toast.id !== id));
  }, []);

  const notify = useCallback(
    (message: string, tone: ToastTone = 'success') => {
      const id = Date.now() + Math.random();
      setToasts((current) => [...current.slice(-2), { id, message, tone }]);
      window.setTimeout(() => dismiss(id), 4200);
    },
    [dismiss]
  );

  const value = useMemo(() => ({ notify }), [notify]);

  return (
    <ToastContext.Provider value={value}>
      {children}
      <div
        className="pointer-events-none fixed inset-x-4 bottom-24 z-[60] flex flex-col items-center gap-2 sm:inset-x-auto sm:right-6 sm:bottom-6 sm:items-end"
        role="status"
        aria-live="polite">
        
        <AnimatePresence initial={false}>
          {toasts.map((toast) =>
          <motion.div
            key={toast.id}
            initial={{ opacity: 0, y: 12, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 8, scale: 0.98 }}
            transition={{ duration: 0.18, ease: [0.23, 1, 0.32, 1] }}
            className={`pointer-events-auto flex w-full max-w-md items-center gap-3 rounded-2xl border px-4 py-3 shadow-lift ${TONE_STYLES[toast.tone].bg}`}>
            
              {TONE_STYLES[toast.tone].icon}
              <p className="flex-1 text-base font-semibold">{toast.message}</p>
              <button
              type="button"
              onClick={() => dismiss(toast.id)}
              className="rounded-full p-1 transition-colors duration-150 hover:bg-black/5"
              aria-label="Dismiss message">
              
                <XIcon className="h-5 w-5" aria-hidden="true" />
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </ToastContext.Provider>);

}

export function useToast(): ToastValue {
  const context = useContext(ToastContext);
  if (!context) throw new Error('useToast must be used inside ToastProvider');
  return context;
}