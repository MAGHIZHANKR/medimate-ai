import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState } from
'react';
import * as db from '../services/db';
import type { AppUser, Role, UserSettings } from '../types';

interface AuthValue {
  user: AppUser | null;
  settings: UserSettings;
  initializing: boolean;
  signIn: (email: string, password: string) => Promise<AppUser>;
  signUp: (input: {
    name: string;
    email: string;
    password: string;
    role: Role;
  }) => Promise<AppUser>;
  signOut: () => void;
  resetPassword: (email: string, password: string) => Promise<void>;
  updateSettings: (patch: Partial<UserSettings>) => void;
  updateName: (name: string) => void;
}

const AuthContext = createContext<AuthValue | null>(null);

export function AuthProvider({ children }: {children: React.ReactNode;}) {
  const [user, setUser] = useState<AppUser | null>(null);
  const [settings, setSettings] = useState<UserSettings>(db.DEFAULT_SETTINGS);
  const [initializing, setInitializing] = useState(true);

  const sync = useCallback(() => {
    const next = db.currentUser();
    setUser(next);
    setSettings(next ? db.getSettings(next.uid) : db.DEFAULT_SETTINGS);
  }, []);

  useEffect(() => {
    sync();
    setInitializing(false);
    return db.subscribe(sync);
  }, [sync]);

  const value = useMemo<AuthValue>(
    () => ({
      user,
      settings,
      initializing,
      signIn: async (email, password) => db.signIn(email, password),
      signUp: async (input) => db.signUp(input),
      signOut: () => db.signOut(),
      resetPassword: async (email, password) => db.resetPassword(email, password),
      updateSettings: (patch) => {
        if (user) db.updateSettings(user.uid, patch);
      },
      updateName: (name) => {
        if (user) db.updateProfile(user.uid, name);
      }
    }),
    [user, settings, initializing]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthValue {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used inside AuthProvider');
  return context;
}