import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState } from
'react';
import * as db from '../services/db';
import { useAuth } from './AuthContext';
import { useToast } from './ToastContext';
import { usePatientData } from '../hooks/usePatientData';
import { useNow } from '../hooks/useNow';
import { showMedicineNotification } from '../services/notifications';
import { buildReminderSentence, speak, stopSpeaking } from '../services/voice';
import { MINUTE, countByStatus, dateKey, formatClock, occurrencesForDay } from '../utils/time';
import type { CaregiverLink, Medicine, MedicineLog, Occurrence } from '../types';
import { ReminderModal } from '../components/ReminderModal';

const MAX_SNOOZES = 3;
const SNOOZE_MINUTES = 10;

interface ReminderValue {
  now: number;
  medicines: Medicine[];
  logs: MedicineLog[];
  links: CaregiverLink[];
  loading: boolean;
  today: string;
  todaysDoses: Occurrence[];
  counts: ReturnType<typeof countByStatus>;
  nextDose: Occurrence | null;
  markTaken: (occurrence: Occurrence) => void;
  snooze: (occurrence: Occurrence) => void;
  markMissed: (occurrence: Occurrence) => void;
  snoozesLeft: (occurrence: Occurrence) => number;
}

const ReminderContext = createContext<ReminderValue | null>(null);

export function ReminderProvider({ children }: {children: React.ReactNode;}) {
  const { user, settings } = useAuth();
  const { notify } = useToast();
  const { medicines, logs, links, loading } = usePatientData(user?.uid);
  const now = useNow(10_000);
  const [busy, setBusy] = useState(false);
  const announced = useRef<Set<string>>(new Set());
  const missedWritten = useRef<Set<string>>(new Set());

  const today = dateKey(new Date(now));
  const grace = settings.gracePeriodMinutes;

  const todaysDoses = useMemo(
    () => occurrencesForDay(medicines, logs, today, grace, now),
    [medicines, logs, today, grace, now]
  );

  const counts = useMemo(() => countByStatus(todaysDoses), [todaysDoses]);

  const nextDose = useMemo(
    () =>
    todaysDoses.find((dose) => dose.status === 'due') ??
    todaysDoses.find((dose) => dose.status === 'snoozed') ??
    todaysDoses.find((dose) => dose.status === 'upcoming') ??
    null,
    [todaysDoses]
  );

  const snoozesLeft = useCallback(
    (occurrence: Occurrence) => MAX_SNOOZES - (occurrence.log?.snoozeCount ?? 0),
    []
  );

  /* Doses that ran past the grace period are recorded as Missed, never dropped. */
  useEffect(() => {
    if (!user) return;
    todaysDoses.forEach((dose) => {
      if (dose.status !== 'missed') return;
      if (dose.log?.status === 'missed') return;
      if (missedWritten.current.has(dose.key)) return;
      missedWritten.current.add(dose.key);
      db.writeLog({
        medicineId: dose.medicine.id,
        userId: user.uid,
        dateKey: dose.dateKey,
        scheduledTime: dose.scheduledTime,
        status: 'missed'
      });
    });
  }, [todaysDoses, user]);

  const activeReminder = useMemo(
    () => todaysDoses.find((dose) => dose.status === 'due') ?? null,
    [todaysDoses]
  );

  /* Announce a due dose exactly once: system notification + spoken reminder. */
  useEffect(() => {
    if (!activeReminder) return;
    if (announced.current.has(activeReminder.key)) return;
    announced.current.add(activeReminder.key);
    const { medicine } = activeReminder;
    showMedicineNotification(
      '💊 Medicine Time',
      `${medicine.name} — ${medicine.dosage}`,
      activeReminder.key
    );
    if (settings.voiceEnabled) {
      speak(buildReminderSentence(medicine.name, medicine.dosage, medicine.foodInstruction));
    }
  }, [activeReminder, settings.voiceEnabled]);

  const act = useCallback(
    (occurrence: Occurrence, status: 'taken' | 'snoozed' | 'missed') => {
      if (!user) return;
      setBusy(true);
      stopSpeaking();
      try {
        const snoozeUntil = Date.now() + SNOOZE_MINUTES * MINUTE;
        db.writeLog({
          medicineId: occurrence.medicine.id,
          userId: user.uid,
          dateKey: occurrence.dateKey,
          scheduledTime: occurrence.scheduledTime,
          status,
          snoozeUntil: status === 'snoozed' ? snoozeUntil : undefined
        });
        if (status === 'taken') notify(`${occurrence.medicine.name} marked as taken`, 'success');
        if (status === 'snoozed') {
          announced.current.delete(occurrence.key);
          notify(`Snoozed until ${formatClock(snoozeUntil)}`, 'info');
        }
        if (status === 'missed') notify(`${occurrence.medicine.name} recorded as missed`, 'error');
      } catch {
        notify('We could not save that just now. Please try again.', 'error');
      } finally {
        setBusy(false);
      }
    },
    [user, notify]
  );

  const value = useMemo<ReminderValue>(
    () => ({
      now,
      medicines,
      logs,
      links,
      loading,
      today,
      todaysDoses,
      counts,
      nextDose,
      markTaken: (occurrence) => act(occurrence, 'taken'),
      snooze: (occurrence) => {
        if (snoozesLeft(occurrence) <= 0) {
          notify('Snooze limit reached for this dose.', 'info');
          return;
        }
        act(occurrence, 'snoozed');
      },
      markMissed: (occurrence) => act(occurrence, 'missed'),
      snoozesLeft
    }),
    [
    now,
    medicines,
    logs,
    links,
    loading,
    today,
    todaysDoses,
    counts,
    nextDose,
    act,
    snoozesLeft,
    notify]

  );

  return (
    <ReminderContext.Provider value={value}>
      {children}
      <ReminderModal
        occurrence={activeReminder}
        snoozesLeft={activeReminder ? snoozesLeft(activeReminder) : 0}
        voiceOn={settings.voiceEnabled}
        busy={busy}
        onRepeatVoice={() => {
          if (!activeReminder) return;
          const { medicine } = activeReminder;
          speak(
            buildReminderSentence(medicine.name, medicine.dosage, medicine.foodInstruction)
          );
        }}
        onTaken={() => activeReminder && act(activeReminder, 'taken')}
        onSnooze={() => {
          if (!activeReminder) return;
          if (snoozesLeft(activeReminder) <= 0) return;
          act(activeReminder, 'snoozed');
        }}
        onMissed={() => activeReminder && act(activeReminder, 'missed')} />
      
    </ReminderContext.Provider>);

}

export function useReminders(): ReminderValue {
  const context = useContext(ReminderContext);
  if (!context) throw new Error('useReminders must be used inside ReminderProvider');
  return context;
}