/**
 * MediMate data layer.
 *
 * Shape-compatible with the Firestore model documented in README.md
 * (users / medicines / medicineLogs / caregiverLinks). Every read is a live
 * subscription, and writes broadcast to other browser tabs via the `storage`
 * event — which is what makes the patient -> caregiver real-time demo work.
 *
 * Swapping this file for the Firebase SDK is a drop-in change: each function
 * below maps 1:1 to a Firestore call (see README "Moving to Firebase").
 */
import type {
  AppUser,
  CaregiverLink,
  Medicine,
  MedicineLog,
  Role,
  UserSettings } from
'../types';
import { dateKey } from '../utils/time';

const KEY = 'medimate.v2';

interface StoredUser extends AppUser {
  password: string;
}

interface DB {
  users: StoredUser[];
  medicines: Medicine[];
  logs: MedicineLog[];
  links: CaregiverLink[];
  settings: Record<string, UserSettings>;
  session: string | null;
}

export const DEFAULT_SETTINGS: UserSettings = {
  voiceEnabled: true,
  gracePeriodMinutes: 30,
  notificationsAsked: false
};

const emptyDb = (): DB => ({
  users: [],
  medicines: [],
  logs: [],
  links: [],
  settings: {},
  session: null
});

const listeners = new Set<() => void>();
let cache: DB | null = null;

function read(): DB {
  if (cache) return cache;
  try {
    const raw = localStorage.getItem(KEY);
    cache = raw ? { ...emptyDb(), ...(JSON.parse(raw) as DB) } : emptyDb();
  } catch {
    cache = emptyDb();
  }
  return cache;
}

function commit(next: DB) {
  cache = next;
  try {
    localStorage.setItem(KEY, JSON.stringify(next));
  } catch {

    /* storage unavailable — session stays in memory */}
  listeners.forEach((fn) => fn());
}

function mutate(fn: (db: DB) => void) {
  const next: DB = JSON.parse(JSON.stringify(read()));
  fn(next);
  commit(next);
}

if (typeof window !== 'undefined') {
  window.addEventListener('storage', (event) => {
    if (event.key && event.key !== KEY) return;
    cache = null;
    listeners.forEach((fn) => fn());
  });
}

export function subscribe(fn: () => void): () => void {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

export function ping() {
  listeners.forEach((fn) => fn());
}

const id = (prefix: string) =>
`${prefix}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;

function makeCaregiverCode(db: DB): string {
  for (let i = 0; i < 200; i += 1) {
    const code = `MED-${Math.floor(1000 + Math.random() * 9000)}`;
    if (!db.users.some((u) => u.caregiverCode === code)) return code;
  }
  return `MED-${Date.now().toString().slice(-4)}`;
}

export class AppError extends Error {}

/* ---------------------------------- auth --------------------------------- */

export function currentUser(): AppUser | null {
  const db = read();
  if (!db.session) return null;
  const user = db.users.find((u) => u.uid === db.session);
  if (!user) return null;
  const { password: _password, ...rest } = user;
  return rest;
}

export function signUp(input: {
  name: string;
  email: string;
  password: string;
  role: Role;
}): AppUser {
  const email = input.email.trim().toLowerCase();
  const db = read();
  if (db.users.some((u) => u.email === email)) {
    throw new AppError('An account already exists with this email. Try logging in instead.');
  }
  const user: StoredUser = {
    uid: id('user'),
    name: input.name.trim(),
    email,
    role: input.role,
    caregiverCode: makeCaregiverCode(db),
    createdAt: Date.now(),
    password: btoa(input.password)
  };
  mutate((next) => {
    next.users.push(user);
    next.settings[user.uid] = { ...DEFAULT_SETTINGS };
    next.session = user.uid;
  });
  const { password: _password, ...rest } = user;
  return rest;
}

export function signIn(email: string, password: string): AppUser {
  const db = read();
  const user = db.users.find((u) => u.email === email.trim().toLowerCase());
  if (!user) throw new AppError('No account found with that email address.');
  if (user.password !== btoa(password)) throw new AppError('That password is incorrect.');
  mutate((next) => {
    next.session = user.uid;
  });
  const { password: _password, ...rest } = user;
  return rest;
}

export function signOut() {
  mutate((next) => {
    next.session = null;
  });
}

export function resetPassword(email: string, password: string) {
  const target = email.trim().toLowerCase();
  const db = read();
  if (!db.users.some((u) => u.email === target)) {
    throw new AppError('No account found with that email address.');
  }
  mutate((next) => {
    const user = next.users.find((u) => u.email === target);
    if (user) user.password = btoa(password);
  });
}

export function updateProfile(uid: string, name: string) {
  mutate((next) => {
    const user = next.users.find((u) => u.uid === uid);
    if (user) user.name = name;
    next.links.
    filter((l) => l.patientId === uid).
    forEach((l) => {
      l.patientName = name;
    });
    next.links.
    filter((l) => l.caregiverId === uid).
    forEach((l) => {
      l.caregiverName = name;
    });
  });
}

export function getUser(uid: string): AppUser | null {
  const user = read().users.find((u) => u.uid === uid);
  if (!user) return null;
  const { password: _password, ...rest } = user;
  return rest;
}

/* -------------------------------- settings ------------------------------- */

export function getSettings(uid: string): UserSettings {
  return { ...DEFAULT_SETTINGS, ...(read().settings[uid] ?? {}) };
}

export function updateSettings(uid: string, patch: Partial<UserSettings>) {
  mutate((next) => {
    next.settings[uid] = { ...DEFAULT_SETTINGS, ...(next.settings[uid] ?? {}), ...patch };
  });
}

/* ------------------------------- medicines ------------------------------- */

export function listMedicines(userId: string): Medicine[] {
  return read().
  medicines.filter((m) => m.userId === userId).
  sort((a, b) => (a.times[0] ?? '').localeCompare(b.times[0] ?? ''));
}

export type MedicineDraft = Omit<Medicine, 'id' | 'userId' | 'createdAt' | 'active'>;

export function addMedicine(userId: string, draft: MedicineDraft): Medicine {
  const medicine: Medicine = {
    ...draft,
    id: id('med'),
    userId,
    active: true,
    createdAt: Date.now()
  };
  mutate((next) => {
    next.medicines.push(medicine);
  });
  return medicine;
}

export function updateMedicine(medicineId: string, patch: Partial<Medicine>) {
  mutate((next) => {
    const medicine = next.medicines.find((m) => m.id === medicineId);
    if (medicine) Object.assign(medicine, patch);
  });
}

export function deleteMedicine(medicineId: string) {
  mutate((next) => {
    next.medicines = next.medicines.filter((m) => m.id !== medicineId);
    next.logs = next.logs.filter((l) => l.medicineId !== medicineId);
  });
}

/* ---------------------------------- logs --------------------------------- */

export function listLogs(userId: string): MedicineLog[] {
  return read().logs.filter((l) => l.userId === userId);
}

interface LogInput {
  medicineId: string;
  userId: string;
  dateKey: string;
  scheduledTime: string;
  status: MedicineLog['status'];
  snoozeUntil?: number;
}

export function writeLog(input: LogInput): MedicineLog {
  let saved: MedicineLog | null = null;
  mutate((next) => {
    const existing = next.logs.find(
      (l) =>
      l.medicineId === input.medicineId &&
      l.dateKey === input.dateKey &&
      l.scheduledTime === input.scheduledTime
    );
    if (existing) {
      existing.status = input.status;
      existing.actionTime = Date.now();
      if (input.status === 'snoozed') {
        existing.snoozeUntil = input.snoozeUntil;
        existing.snoozeCount = (existing.snoozeCount ?? 0) + 1;
      }
      saved = existing;
      return;
    }
    const log: MedicineLog = {
      id: id('log'),
      medicineId: input.medicineId,
      userId: input.userId,
      dateKey: input.dateKey,
      scheduledTime: input.scheduledTime,
      status: input.status,
      actionTime: Date.now(),
      snoozeUntil: input.status === 'snoozed' ? input.snoozeUntil : undefined,
      snoozeCount: input.status === 'snoozed' ? 1 : 0,
      createdAt: Date.now()
    };
    next.logs.push(log);
    saved = log;
  });
  return saved as unknown as MedicineLog;
}

/* ---------------------------- caregiver links ---------------------------- */

export function listLinks(uid: string): CaregiverLink[] {
  return read().
  links.filter((l) => l.patientId === uid || l.caregiverId === uid).
  sort((a, b) => b.createdAt - a.createdAt);
}

export function requestLink(caregiver: AppUser, code: string): CaregiverLink {
  const normalized = code.trim().toUpperCase();
  const db = read();
  const patient = db.users.find(
    (u) => u.caregiverCode === normalized && u.role === 'patient'
  );
  if (!patient) throw new AppError('No patient found with that code. Check the code and try again.');
  if (
  db.links.some(
    (l) =>
    l.patientId === patient.uid &&
    l.caregiverId === caregiver.uid &&
    l.status !== 'declined'
  ))
  {
    throw new AppError('You have already requested access to this patient.');
  }
  const link: CaregiverLink = {
    id: id('link'),
    patientId: patient.uid,
    caregiverId: caregiver.uid,
    caregiverName: caregiver.name,
    patientName: patient.name,
    status: 'pending',
    createdAt: Date.now()
  };
  mutate((next) => {
    next.links.push(link);
  });
  return link;
}

export function setLinkStatus(linkId: string, status: CaregiverLink['status']) {
  mutate((next) => {
    const link = next.links.find((l) => l.id === linkId);
    if (link) link.status = status;
  });
}

export function removeLink(linkId: string) {
  mutate((next) => {
    next.links = next.links.filter((l) => l.id !== linkId);
  });
}

/** Caregivers may only read patients they are approved for. */
export function patientDataFor(caregiverId: string, patientId: string) {
  const db = read();
  const approved = db.links.some(
    (l) =>
    l.caregiverId === caregiverId && l.patientId === patientId && l.status === 'approved'
  );
  if (!approved) return null;
  return {
    patient: getUser(patientId),
    medicines: listMedicines(patientId),
    logs: listLogs(patientId),
    settings: getSettings(patientId)
  };
}

/* ------------------------------- demo data ------------------------------- */

export function hasDemoData(userId: string): boolean {
  return read().medicines.some((m) => m.userId === userId && m.demo);
}

export function seedDemoData(userId: string) {
  const today = dateKey(new Date());
  const now = new Date();
  const soon = new Date(now.getTime() + 3 * 60_000);
  const soonTime = `${`${soon.getHours()}`.padStart(2, '0')}:${`${soon.getMinutes()}`.padStart(2, '0')}`;

  const drafts: MedicineDraft[] = [
  {
    name: 'Metformin',
    dosage: '1 tablet',
    times: [soonTime],
    frequency: 'daily',
    foodInstruction: 'after',
    startDate: today,
    endDate: null,
    notes: 'Demo medicine — safe to delete.',
    demo: true
  },
  {
    name: 'Vitamin D',
    dosage: '1 capsule',
    times: ['13:00'],
    frequency: 'daily',
    foodInstruction: 'after',
    startDate: today,
    endDate: null,
    notes: '',
    demo: true
  },
  {
    name: 'BP Tablet',
    dosage: '1 tablet',
    times: ['20:00'],
    frequency: 'daily',
    foodInstruction: 'after',
    startDate: today,
    endDate: null,
    notes: '',
    demo: true
  }];

  drafts.forEach((draft) => addMedicine(userId, draft));
}

export function clearDemoData(userId: string) {
  mutate((next) => {
    const ids = next.medicines.filter((m) => m.userId === userId && m.demo).map((m) => m.id);
    next.medicines = next.medicines.filter((m) => !ids.includes(m.id));
    next.logs = next.logs.filter((l) => !ids.includes(l.medicineId));
  });
}