export type PermissionState = 'granted' | 'denied' | 'default' | 'unsupported';

export function notificationState(): PermissionState {
  if (typeof window === 'undefined' || !('Notification' in window)) return 'unsupported';
  return Notification.permission as PermissionState;
}

export async function requestNotificationPermission(): Promise<PermissionState> {
  if (notificationState() === 'unsupported') return 'unsupported';
  try {
    const result = await Notification.requestPermission();
    return result as PermissionState;
  } catch {
    return 'denied';
  }
}

/** Fires a system notification when allowed. In-app reminders never depend on this. */
export function showMedicineNotification(title: string, body: string, tag: string) {
  if (notificationState() !== 'granted') return;
  try {
    const notification = new Notification(title, { body, tag, requireInteraction: false });
    notification.onclick = () => {
      window.focus();
      notification.close();
    };
  } catch {

    /* notification construction can throw in some embedded contexts */}
}