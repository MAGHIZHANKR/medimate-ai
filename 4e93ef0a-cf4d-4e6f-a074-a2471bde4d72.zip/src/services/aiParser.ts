/**
 * Natural-language reminder parser.
 *
 * Converts a sentence like "Remind me to take my BP tablet every morning after
 * breakfast at 8" into structured reminder fields. It NEVER invents a medicine
 * name, dosage, time, or frequency: anything it cannot read confidently is
 * returned as a failure so the user falls back to the manual form.
 *
 * If VITE_GEMINI_API_KEY is configured, `parseReminderText` calls Gemini first
 * and uses this deterministic parser as the offline fallback.
 */
import type { FoodInstruction, Frequency } from '../types';
import { defaultTimesFor } from '../utils/time';

export interface ParsedReminder {
  name: string;
  dosage: string;
  times: string[];
  frequency: Frequency;
  foodInstruction: FoodInstruction;
  notes: string;
}

export type ParseResult =
{ok: true;value: ParsedReminder;source: 'gemini' | 'local';} |
{ok: false;message: string;};

const FAILURE =
"I couldn't understand the medicine schedule clearly. Please enter it manually.";

const DOSAGE_UNITS = [
'tablet',
'tablets',
'capsule',
'capsules',
'pill',
'pills',
'ml',
'drop',
'drops',
'spoon',
'spoons',
'injection',
'puff',
'puffs',
'sachet'];


const NUMBER_WORDS: Record<string, number> = {
  one: 1,
  two: 2,
  three: 3,
  half: 1,
  a: 1,
  an: 1
};

function extractTimes(text: string): string[] {
  const times: string[] = [];
  const explicit = text.matchAll(/(\d{1,2})(?::(\d{2}))?\s*(am|pm|a\.m\.|p\.m\.)?/gi);
  for (const match of explicit) {
    const raw = match[0].toLowerCase();
    let hour = Number(match[1]);
    const minute = Number(match[2] ?? 0);
    const period = (match[3] ?? '').replace(/\./g, '');
    const hasContext = /at\s*$/i.test(text.slice(0, match.index ?? 0)) || Boolean(period);
    if (!hasContext) continue;
    if (hour > 24 || minute > 59) continue;
    if (period === 'pm' && hour < 12) hour += 12;
    if (period === 'am' && hour === 12) hour = 0;
    if (!period) {
      // "at 8" with a morning/night cue
      if (/night|evening|dinner|bed/i.test(text) && hour < 12) hour += 12;else
      if (/afternoon|lunch/i.test(text) && hour < 12 && hour !== 12) hour += 12;
    }
    if (hour > 23) continue;
    const value = `${`${hour}`.padStart(2, '0')}:${`${minute}`.padStart(2, '0')}`;
    if (!times.includes(value)) times.push(value);
  }
  if (times.length) return times.sort();

  const cues: string[] = [];
  if (/morning|breakfast/i.test(text)) cues.push('08:00');
  if (/lunch|afternoon|noon/i.test(text)) cues.push('13:00');
  if (/evening|dinner|night|bed/i.test(text)) cues.push('20:00');
  return [...new Set(cues)].sort();
}

function extractFrequency(text: string, timeCount: number): Frequency | null {
  if (/three times|thrice|3 times/i.test(text)) return 'three';
  if (/twice|two times|2 times/i.test(text)) return 'twice';
  if (/every ?day|daily|each day|every morning|every night|every evening/i.test(text)) {
    return timeCount >= 3 ? 'three' : timeCount === 2 ? 'twice' : 'daily';
  }
  if (/once only|just once|one time|today only/i.test(text)) return 'once';
  if (timeCount >= 3) return 'three';
  if (timeCount === 2) return 'twice';
  if (timeCount === 1) return 'daily';
  return null;
}

function extractFood(text: string): FoodInstruction {
  if (/before (food|meal|breakfast|lunch|dinner|eating)|empty stomach/i.test(text)) return 'before';
  if (/with (food|meal|milk|water and food)/i.test(text)) return 'with';
  if (/after (food|meal|breakfast|lunch|dinner|eating)/i.test(text)) return 'after';
  return 'none';
}

function extractDosage(text: string): string | null {
  const unit = DOSAGE_UNITS.join('|');
  const numeric = text.match(new RegExp(`(\\d+(?:\\.\\d+)?)\\s*(${unit})\\b`, 'i'));
  if (numeric) return `${numeric[1]} ${numeric[2].toLowerCase()}`;
  const worded = text.match(new RegExp(`\\b(one|two|three|half|a|an)\\s+(${unit})\\b`, 'i'));
  if (worded) {
    const count = NUMBER_WORDS[worded[1].toLowerCase()] ?? 1;
    const suffix = worded[1].toLowerCase() === 'half' ? 'half a ' : '';
    return `${suffix ? '' : count} ${suffix}${worded[2].toLowerCase()}`.trim();
  }
  const bare = text.match(new RegExp(`\\b(${unit})\\b`, 'i'));
  if (bare) return `1 ${bare[1].toLowerCase()}`;
  return null;
}

function extractName(text: string): string | null {
  const match = text.match(
    /(?:take|taking|for|of)\s+(?:my|the|a|an)?\s*([a-z0-9][a-z0-9\-+.]*(?:\s+[a-z0-9][a-z0-9\-+.]*)?)/i
  );
  if (!match) return null;
  const stop = new Set([
  'medicine',
  'medicines',
  'medication',
  'tablet',
  'tablets',
  'capsule',
  'capsules',
  'pill',
  'pills',
  'dose',
  'doses',
  'it',
  'them',
  'this',
  'that',
  'every',
  'daily',
  'my']
  );
  const words = match[1].
  split(/\s+/).
  filter((word) => word.length > 1 && !stop.has(word.toLowerCase())).
  slice(0, 3);
  if (!words.length) return null;
  const name = words.
  map((word) => word.charAt(0).toUpperCase() + word.slice(1)).
  join(' ').
  trim();
  return name.length >= 2 ? name : null;
}

export function parseLocally(input: string): ParseResult {
  const text = input.trim();
  if (text.length < 8) return { ok: false, message: FAILURE };

  const name = extractName(text);
  const times = extractTimes(text);
  if (!name || !times.length) return { ok: false, message: FAILURE };

  const frequency = extractFrequency(text, times.length);
  if (!frequency) return { ok: false, message: FAILURE };

  const expected = frequency === 'three' ? 3 : frequency === 'twice' ? 2 : 1;
  const resolvedTimes =
  times.length === expected ?
  times :
  times.length > expected ?
  times.slice(0, expected) :
  [...times, ...defaultTimesFor(frequency).slice(times.length)].slice(0, expected);

  const dosage = extractDosage(text);
  const dosageFromName = /tablet|capsule|pill/i.test(name) ? '1 tablet' : null;

  return {
    ok: true,
    source: 'local',
    value: {
      name,
      dosage: dosage ?? dosageFromName ?? '',
      times: resolvedTimes,
      frequency: times.length > expected ? 'custom' : frequency,
      foodInstruction: extractFood(text),
      notes: ''
    }
  };
}

const GEMINI_KEY =
typeof import.meta !== 'undefined' &&
(import.meta as unknown as {env?: Record<string, string>;}).env?.
VITE_GEMINI_API_KEY ||
'';

export function aiConfigured(): boolean {
  return Boolean(GEMINI_KEY);
}

const SYSTEM_PROMPT = `You convert a caregiver's plain-language sentence into a medicine reminder.
Return ONLY JSON: {"name":string,"dosage":string,"times":["HH:MM"],"frequency":"once|daily|twice|three|custom","foodInstruction":"before|after|with|none","confident":boolean}
Rules: never invent a medicine name, dosage, time or frequency that is not stated or clearly implied.
Never recommend a medicine, a dosage, or any treatment. If anything is unclear set "confident" to false.`;

export async function parseReminderText(input: string): Promise<ParseResult> {
  if (!GEMINI_KEY) return parseLocally(input);
  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_KEY}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: SYSTEM_PROMPT }] },
          contents: [{ role: 'user', parts: [{ text: input }] }],
          generationConfig: { temperature: 0, responseMimeType: 'application/json' }
        })
      }
    );
    if (!response.ok) return parseLocally(input);
    const payload = await response.json();
    const raw = payload?.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!raw) return parseLocally(input);
    const parsed = JSON.parse(raw);
    if (
    !parsed?.confident ||
    typeof parsed.name !== 'string' ||
    !Array.isArray(parsed.times) ||
    !parsed.times.length)
    {
      return { ok: false, message: FAILURE };
    }
    return {
      ok: true,
      source: 'gemini',
      value: {
        name: parsed.name,
        dosage: typeof parsed.dosage === 'string' ? parsed.dosage : '',
        times: parsed.times.filter((t: unknown) => typeof t === 'string'),
        frequency: (parsed.frequency ?? 'daily') as Frequency,
        foodInstruction: (parsed.foodInstruction ?? 'none') as FoodInstruction,
        notes: ''
      }
    };
  } catch {
    return parseLocally(input);
  }
}

export const AI_FAILURE_MESSAGE = FAILURE;