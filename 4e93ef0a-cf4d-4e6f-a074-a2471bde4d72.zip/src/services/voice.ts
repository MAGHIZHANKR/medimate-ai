import { FOOD_LABEL } from '../utils/time';
import type { FoodInstruction } from '../types';

export function voiceSupported(): boolean {
  return typeof window !== 'undefined' && 'speechSynthesis' in window;
}

export function buildReminderSentence(
name: string,
dosage: string,
food: FoodInstruction)
: string {
  const foodPart = food === 'none' ? '' : `, ${FOOD_LABEL[food].toLowerCase()}`;
  return `It's medicine time. Please take ${name}, ${dosage}${foodPart}.`;
}

export function speak(text: string) {
  if (!voiceSupported()) return;
  try {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 0.92;
    utterance.pitch = 1;
    utterance.volume = 1;
    window.speechSynthesis.speak(utterance);
  } catch {

    /* speech unavailable — reminder UI still shows */}
}

export function stopSpeaking() {
  if (!voiceSupported()) return;
  try {
    window.speechSynthesis.cancel();
  } catch {

    /* no-op */}
}