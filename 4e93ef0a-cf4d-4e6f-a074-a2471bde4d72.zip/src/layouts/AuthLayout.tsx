import React from 'react';
import { Outlet } from 'react-router-dom';
import { BellRingIcon, HeartHandshakeIcon, MicIcon } from 'lucide-react';
import { Wordmark } from '../components/Brand';

const HIGHLIGHTS = [
{
  icon: <BellRingIcon className="h-6 w-6" aria-hidden="true" />,
  title: 'Reminders that actually ring',
  body: 'Browser notifications plus a large on-screen reminder at every scheduled dose.'
},
{
  icon: <MicIcon className="h-6 w-6" aria-hidden="true" />,
  title: 'Spoken out loud',
  body: '“It’s medicine time. Please take Metformin, one tablet, after breakfast.”'
},
{
  icon: <HeartHandshakeIcon className="h-6 w-6" aria-hidden="true" />,
  title: 'Family can follow along',
  body: 'A caregiver you approve sees Taken, Snoozed and Missed as it happens.'
}];


export function AuthLayout() {
  return (
    <div className="grid min-h-full w-full lg:grid-cols-[1.05fr_1fr]">
      <section className="hidden flex-col justify-between bg-primary-700 px-12 py-14 text-white lg:flex">
        <div>
          <span className="flex items-center gap-3">
            <span className="text-3xl font-extrabold tracking-tight">MEDIMATE</span>
          </span>
          <p className="mt-2 text-lg text-primary-100">Never miss a medicine moment.</p>
          <h1 className="mt-14 max-w-md text-4xl font-extrabold leading-tight">
            A medicine reminder simple enough for every day.
          </h1>
        </div>

        <ul className="mt-12 flex flex-col gap-7">
          {HIGHLIGHTS.map((item) =>
          <li key={item.title} className="flex gap-4">
              <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-primary-600 text-white">
                {item.icon}
              </span>
              <div>
                <p className="text-lg font-bold">{item.title}</p>
                <p className="mt-1 max-w-sm text-base text-primary-100">{item.body}</p>
              </div>
            </li>
          )}
        </ul>

        <p className="mt-12 max-w-md text-sm text-primary-200">
          MediMate provides reminders and self-reported tracking only. It does not provide medical
          advice, verify medication intake, or replace a healthcare professional.
        </p>
      </section>

      <section className="flex flex-col justify-center bg-canvas px-4 py-10 sm:px-8">
        <div className="mx-auto w-full max-w-md">
          <div className="mb-8 lg:hidden">
            <Wordmark size="lg" />
          </div>
          <Outlet />
        </div>
      </section>
    </div>);

}