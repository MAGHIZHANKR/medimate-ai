import React from 'react';
import { NavLink, Outlet, useLocation } from 'react-router-dom';
import {
  ActivityIcon,
  BellIcon,
  ClipboardListIcon,
  HomeIcon,
  LogOutIcon,
  PillIcon,
  SettingsIcon,
  UserRoundIcon,
  UsersRoundIcon } from
'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { Logo } from '../components/Brand';
import { Button } from '../components/ui/Button';
import { notificationState } from '../services/notifications';

interface NavItem {
  to: string;
  label: string;
  icon: React.ReactNode;
}

const PATIENT_NAV: NavItem[] = [
{ to: '/dashboard', label: 'Dashboard', icon: <HomeIcon className="h-6 w-6" /> },
{ to: '/medicines', label: 'Medicines', icon: <PillIcon className="h-6 w-6 -rotate-45" /> },
{ to: '/history', label: 'History', icon: <ClipboardListIcon className="h-6 w-6" /> },
{ to: '/caregiver', label: 'Caregiver', icon: <UserRoundIcon className="h-6 w-6" /> },
{ to: '/settings', label: 'Settings', icon: <SettingsIcon className="h-6 w-6" /> }];


const CAREGIVER_NAV: NavItem[] = [
{ to: '/dashboard', label: 'Dashboard', icon: <HomeIcon className="h-6 w-6" /> },
{ to: '/patients', label: 'Patients', icon: <UsersRoundIcon className="h-6 w-6" /> },
{ to: '/activity', label: 'Activity', icon: <ActivityIcon className="h-6 w-6" /> },
{ to: '/settings', label: 'Settings', icon: <SettingsIcon className="h-6 w-6" /> }];


export function AppLayout() {
  const { user, signOut } = useAuth();
  const location = useLocation();
  const items = user?.role === 'caregiver' ? CAREGIVER_NAV : PATIENT_NAV;
  const notifications = notificationState();

  return (
    <div className="flex min-h-full w-full bg-canvas">
      <aside className="hidden w-72 shrink-0 flex-col border-r border-line bg-surface px-5 py-6 lg:flex">
        <div className="flex items-center gap-3">
          <Logo />
          <div className="leading-tight">
            <p className="text-lg font-extrabold tracking-tight text-ink">MEDIMATE</p>
            <p className="text-sm text-ink-muted">Never miss a medicine moment.</p>
          </div>
        </div>

        <nav aria-label="Main" className="mt-8 flex flex-1 flex-col gap-1.5">
          {items.map((item) =>
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) =>
            `flex min-h-[54px] items-center gap-3 rounded-2xl px-4 text-lg font-semibold transition-colors duration-150 ease-out ${
            isActive ||
            item.to === '/patients' && location.pathname.startsWith('/patients') ?
            'bg-primary-600 text-white' :
            'text-ink-muted hover:bg-primary-50 hover:text-primary-700'}`

            }>
            
              <span aria-hidden="true">{item.icon}</span>
              {item.label}
            </NavLink>
          )}
        </nav>

        <div className="mt-6 rounded-2xl border border-line bg-canvas p-4">
          <p className="text-base font-bold text-ink">{user?.name}</p>
          <p className="text-sm capitalize text-ink-muted">{user?.role}</p>
          {notifications !== 'granted' &&
          <p className="mt-3 flex items-start gap-2 text-sm text-status-snoozed">
              <BellIcon className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
              In-app reminders only — system notifications are off.
            </p>
          }
          <Button variant="secondary" className="mt-4 w-full" onClick={signOut}>
            <LogOutIcon className="h-5 w-5" aria-hidden="true" />
            Log out
          </Button>
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 flex items-center justify-between gap-3 border-b border-line bg-surface/95 px-4 py-3 backdrop-blur lg:hidden">
          <div className="flex items-center gap-2.5">
            <Logo />
            <span className="text-lg font-extrabold tracking-tight text-ink">MEDIMATE</span>
          </div>
          <Button variant="ghost" onClick={signOut} className="min-h-[44px] px-3">
            <LogOutIcon className="h-5 w-5" aria-hidden="true" />
            Log out
          </Button>
        </header>

        <main className="flex-1 px-4 pb-28 pt-5 sm:px-6 lg:px-10 lg:pb-12 lg:pt-8">
          <div className="mx-auto w-full max-w-6xl">
            <Outlet />
          </div>
        </main>

        <nav
          aria-label="Main"
          className="fixed inset-x-0 bottom-0 z-40 grid grid-flow-col border-t border-line bg-surface px-1 pb-1 pt-1.5 lg:hidden">
          
          {items.map((item) =>
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) =>
            `flex min-h-[62px] flex-col items-center justify-center gap-1 rounded-xl px-1 text-xs font-bold transition-colors duration-150 ease-out ${
            isActive ||
            item.to === '/patients' && location.pathname.startsWith('/patients') ?
            'bg-primary-50 text-primary-700' :
            'text-ink-muted'}`

            }>
            
              <span aria-hidden="true">{item.icon}</span>
              {item.label}
            </NavLink>
          )}
        </nav>
      </div>
    </div>);

}