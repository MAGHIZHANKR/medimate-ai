import { useEffect, useState } from 'react';
import * as db from '../services/db';
import type { AppUser, CaregiverLink, Medicine, MedicineLog, UserSettings } from '../types';

export interface PatientBundle {
  link: CaregiverLink;
  patient: AppUser;
  medicines: Medicine[];
  logs: MedicineLog[];
  settings: UserSettings;
}

interface CaregiverData {
  loading: boolean;
  links: CaregiverLink[];
  pending: CaregiverLink[];
  patients: PatientBundle[];
}

/** Live caregiver view. Only approved links resolve to patient data. */
export function useCaregiverPatients(caregiverId: string | undefined): CaregiverData {
  const [state, setState] = useState<CaregiverData>({
    loading: true,
    links: [],
    pending: [],
    patients: []
  });

  useEffect(() => {
    if (!caregiverId) {
      setState({ loading: false, links: [], pending: [], patients: [] });
      return;
    }
    const load = () => {
      const links = db.listLinks(caregiverId).filter((l) => l.caregiverId === caregiverId);
      const patients: PatientBundle[] = [];
      links.
      filter((link) => link.status === 'approved').
      forEach((link) => {
        const bundle = db.patientDataFor(caregiverId, link.patientId);
        if (bundle?.patient) {
          patients.push({
            link,
            patient: bundle.patient,
            medicines: bundle.medicines,
            logs: bundle.logs,
            settings: bundle.settings
          });
        }
      });
      setState({
        loading: false,
        links,
        pending: links.filter((link) => link.status === 'pending'),
        patients
      });
    };
    load();
    return db.subscribe(load);
  }, [caregiverId]);

  return state;
}