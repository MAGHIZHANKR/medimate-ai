import { useEffect, useState } from 'react';
import * as db from '../services/db';
import type { CaregiverLink, Medicine, MedicineLog } from '../types';

interface PatientData {
  medicines: Medicine[];
  logs: MedicineLog[];
  links: CaregiverLink[];
  loading: boolean;
}

/** Live subscription to one user's medicines, logs and caregiver links. */
export function usePatientData(userId: string | undefined): PatientData {
  const [state, setState] = useState<PatientData>({
    medicines: [],
    logs: [],
    links: [],
    loading: true
  });

  useEffect(() => {
    if (!userId) {
      setState({ medicines: [], logs: [], links: [], loading: false });
      return;
    }
    const load = () => {
      setState({
        medicines: db.listMedicines(userId),
        logs: db.listLogs(userId),
        links: db.listLinks(userId),
        loading: false
      });
    };
    load();
    return db.subscribe(load);
  }, [userId]);

  return state;
}